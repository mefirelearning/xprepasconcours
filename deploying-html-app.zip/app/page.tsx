"use client"

import { useState } from "react"
import { LandingView } from "@/components/views/landing-view"
import { AuthView } from "@/components/views/auth-view"
import { ConcoursSelector } from "@/components/views/concours-selector"
import { WizardView } from "@/components/views/wizard-view"
import { MainApp } from "@/components/views/main-app"
import { BackgroundSymbols } from "@/components/ui/background-symbols"

export type ViewType = "landing" | "auth" | "concours" | "wizard" | "app"
export type AuthMode = "login" | "register"

export default function Home() {
  const [currentView, setCurrentView] = useState<ViewType>("landing")
  const [authMode, setAuthMode] = useState<AuthMode>("login")
  const [selectedConcours, setSelectedConcours] = useState<string[]>([])
  const [isDark, setIsDark] = useState(false)

  const toggleTheme = () => {
    setIsDark(!isDark)
    document.documentElement.classList.toggle("dark", !isDark)
  }

  return (
    <div className={`mesh-bg ${isDark ? "" : "light"}`}>
      <BackgroundSymbols />
      
      {currentView === "landing" && (
        <LandingView 
          onLogin={() => { setAuthMode("login"); setCurrentView("auth") }}
          onRegister={() => { setAuthMode("register"); setCurrentView("auth") }}
        />
      )}
      
      {currentView === "auth" && (
        <AuthView 
          mode={authMode}
          setMode={setAuthMode}
          onBack={() => setCurrentView("landing")}
          onSuccess={() => setCurrentView("concours")}
        />
      )}
      
      {currentView === "concours" && (
        <ConcoursSelector
          selectedConcours={selectedConcours}
          setSelectedConcours={setSelectedConcours}
          onBack={() => setCurrentView("auth")}
          onContinue={() => setCurrentView("wizard")}
          onSkip={() => setCurrentView("app")}
        />
      )}
      
      {currentView === "wizard" && (
        <WizardView
          onComplete={() => setCurrentView("app")}
        />
      )}
      
      {currentView === "app" && (
        <MainApp 
          isDark={isDark}
          toggleTheme={toggleTheme}
        />
      )}
    </div>
  )
}
