export function LogoMark({ size = 34 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100">
      <defs>
        <linearGradient id="logoGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--cyn)" />
          <stop offset="100%" stopColor="var(--vio)" />
        </linearGradient>
        <linearGradient id="logoGrad2" x1="100%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="var(--vio)" />
          <stop offset="100%" stopColor="var(--ros)" />
        </linearGradient>
      </defs>
      <circle 
        className="logo-ring-1"
        cx="50" cy="50" r="44" 
        fill="none" 
        stroke="url(#logoGrad1)" 
        strokeWidth="3" 
        strokeDasharray="55 30" 
        opacity="0.9"
      />
      <circle 
        className="logo-ring-2"
        cx="50" cy="50" r="32" 
        fill="none" 
        stroke="url(#logoGrad2)" 
        strokeWidth="2" 
        strokeDasharray="35 20" 
        opacity="0.6"
      />
      <text 
        className="logo-center"
        x="50" y="58" 
        textAnchor="middle" 
        fontSize="32" 
        fontWeight="900" 
        fill="url(#logoGrad1)" 
        fontFamily="var(--font-syne), Syne, sans-serif"
      >
        P
      </text>
    </svg>
  )
}

export function LogoFull() {
  return (
    <div className="flex items-center gap-2.5">
      <LogoMark />
      <span className="font-[var(--font-syne)] text-sm font-extrabold gradient-text">
        Prépas Concours AI
      </span>
    </div>
  )
}
