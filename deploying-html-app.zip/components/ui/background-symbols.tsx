export function BackgroundSymbols() {
  const symbols = ["∑", "∫", "π", "∆", "√", "∞", "θ", "λ"]
  const positions = [
    { top: "3%", left: "6%", size: "clamp(38px, 7vw, 70px)", delay: "0s" },
    { top: "10%", right: "8%", size: "clamp(32px, 5.5vw, 55px)", delay: "-5s" },
    { top: "30%", left: "3%", size: "clamp(28px, 5vw, 48px)", delay: "-9s" },
    { top: "45%", right: "4%", size: "clamp(42px, 8vw, 80px)", delay: "-13s" },
    { top: "65%", left: "10%", size: "clamp(34px, 6.5vw, 62px)", delay: "-17s" },
    { bottom: "6%", right: "14%", size: "clamp(28px, 5vw, 50px)", delay: "-21s" },
    { top: "20%", left: "42%", size: "clamp(32px, 6vw, 58px)", delay: "-7s" },
    { bottom: "25%", left: "52%", size: "clamp(36px, 7vw, 66px)", delay: "-15s" },
  ]

  return (
    <div className="bg-symbols">
      {symbols.map((symbol, index) => (
        <span
          key={index}
          className="symbol font-[var(--font-syne)]"
          style={{
            ...positions[index],
            fontSize: positions[index].size,
            animationDelay: positions[index].delay,
          }}
        >
          {symbol}
        </span>
      ))}
    </div>
  )
}
