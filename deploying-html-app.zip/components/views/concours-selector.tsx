"use client"

import { ArrowLeft, Check, Building2, Heart, Shield, BookOpen, DollarSign, Star } from "lucide-react"

interface ConcoursSelectorProps {
  selectedConcours: string[]
  setSelectedConcours: (concours: string[]) => void
  onBack: () => void
  onContinue: () => void
  onSkip: () => void
}

const concoursData = [
  { code: "ENAM", name: "Administration", count: "47 épreuves", color: "ca", icon: Building2, stroke: "var(--ind2)" },
  { code: "FMSB", name: "Médecine", count: "38 épreuves", color: "cb", icon: Heart, stroke: "var(--cyn)" },
  { code: "ENSP", name: "Police", count: "29 épreuves", color: "cc", icon: Shield, stroke: "var(--grn)" },
  { code: "ENS", name: "Enseignement", count: "33 épreuves", color: "cd", icon: BookOpen, stroke: "var(--amb)" },
  { code: "ESSEC", name: "Commerce", count: "22 épreuves", color: "ce", icon: DollarSign, stroke: "var(--vio)" },
  { code: "IUT", name: "Technologie", count: "18 épreuves", color: "cf", icon: Star, stroke: "var(--ros)" },
]

const colorMap: Record<string, { gradient: string; bg: string; badge: string; badgeColor: string }> = {
  ca: { gradient: "linear-gradient(90deg, var(--ind), var(--cyn))", bg: "var(--ind-g)", badge: "var(--ind-g)", badgeColor: "var(--ind2)" },
  cb: { gradient: "linear-gradient(90deg, var(--cyn), var(--grn))", bg: "var(--cyn-g)", badge: "var(--cyn-g)", badgeColor: "var(--cyn)" },
  cc: { gradient: "linear-gradient(90deg, var(--grn), var(--amb))", bg: "rgba(15,227,163,.12)", badge: "rgba(15,227,163,.12)", badgeColor: "var(--grn)" },
  cd: { gradient: "linear-gradient(90deg, var(--amb), var(--ros))", bg: "var(--amb-g)", badge: "var(--amb-g)", badgeColor: "var(--amb)" },
  ce: { gradient: "linear-gradient(90deg, var(--vio), var(--ros))", bg: "var(--vio-g)", badge: "var(--vio-g)", badgeColor: "var(--vio)" },
  cf: { gradient: "linear-gradient(90deg, var(--ros), var(--ind))", bg: "var(--ros-g)", badge: "var(--ros-g)", badgeColor: "var(--ros)" },
}

export function ConcoursSelector({ selectedConcours, setSelectedConcours, onBack, onContinue, onSkip }: ConcoursSelectorProps) {
  const toggleConcours = (code: string) => {
    if (selectedConcours.includes(code)) {
      setSelectedConcours(selectedConcours.filter(c => c !== code))
    } else {
      setSelectedConcours([...selectedConcours, code])
    }
  }

  return (
    <div className="fixed inset-0 z-10 flex flex-col items-center overflow-y-auto p-5 pb-15">
      <div className="w-full max-w-[600px] text-center mb-5">
        <button 
          onClick={onBack}
          className="inline-flex items-center gap-[5px] text-xs text-[var(--t3)] cursor-pointer mb-4 hover:text-[var(--t1)] transition-colors"
        >
          <ArrowLeft size={14} />
          Retour
        </button>
        
        <h2 className="font-[var(--font-syne)] text-[clamp(22px,5.5vw,30px)] font-extrabold text-[var(--t1)] mb-[7px]">
          Quel concours <span className="gradient-text">prépares-tu ?</span>
        </h2>
        <p className="text-[13px] text-[var(--t2)]">Choisis pour personnaliser ton planning</p>
      </div>

      <div className="w-full max-w-[600px] grid grid-cols-2 sm:grid-cols-3 gap-3 mb-5">
        {concoursData.map((concours) => {
          const isSelected = selectedConcours.includes(concours.code)
          const colors = colorMap[concours.color]
          const Icon = concours.icon
          
          return (
            <div 
              key={concours.code}
              onClick={() => toggleConcours(concours.code)}
              className={`bg-[var(--surf)] border-[1.5px] rounded-[14px] p-4 cursor-pointer transition-all relative overflow-hidden hover:-translate-y-0.5 ${
                isSelected 
                  ? "border-[var(--cyn)] shadow-[0_0_0_2px_var(--cyn-g)]" 
                  : "border-[var(--b0)] hover:border-[var(--b1)]"
              }`}
            >
              <div 
                className="absolute top-0 left-0 right-0 h-[3px]"
                style={{ background: colors.gradient }}
              />
              
              {isSelected && (
                <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-[var(--cyn)] text-black text-[10px] font-extrabold flex items-center justify-center">
                  <Check size={12} />
                </div>
              )}
              
              <div 
                className="w-9 h-9 rounded-[10px] flex items-center justify-center mb-2"
                style={{ background: colors.bg }}
              >
                <Icon size={18} stroke={concours.stroke} strokeWidth={1.6} />
              </div>
              
              <div className="font-[var(--font-syne)] text-base font-black text-[var(--t1)] mb-0.5">
                {concours.code}
              </div>
              <div className="text-[10px] text-[var(--t3)] mb-2">
                {concours.name}
              </div>
              <span 
                className="text-[9.5px] font-bold py-0.5 px-2 rounded-[20px]"
                style={{ background: colors.badge, color: colors.badgeColor }}
              >
                {concours.count}
              </span>
            </div>
          )
        })}
      </div>

      <button 
        onClick={onContinue}
        disabled={selectedConcours.length === 0}
        className="py-3 px-8 btn-primary rounded-[25px] font-[var(--font-syne)] text-sm font-bold text-white transition-all disabled:opacity-40 disabled:cursor-not-allowed hover:enabled:scale-[1.04]"
      >
        Créer mon planning →
      </button>
      
      <button 
        onClick={onSkip}
        className="mt-2.5 text-xs text-[var(--t3)] cursor-pointer hover:text-[var(--t1)] transition-colors"
      >
        Passer → entrer dans l&apos;app
      </button>
    </div>
  )
}
