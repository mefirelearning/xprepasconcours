"use client"

import { LogoFull } from "@/components/ui/logo"

interface LandingViewProps {
  onLogin: () => void
  onRegister: () => void
}

export function LandingView({ onLogin, onRegister }: LandingViewProps) {
  return (
    <div className="fixed inset-0 z-10 flex flex-col overflow-y-auto" style={{ scrollbarWidth: "thin", scrollbarColor: "var(--b1) transparent" }}>
      {/* Header */}
      <header className="flex items-center justify-between px-5 py-4 shrink-0">
        <LogoFull />
        <div className="flex gap-2">
          <button 
            onClick={onLogin}
            className="px-4 py-2 rounded-[20px] text-[13px] font-semibold bg-transparent text-[var(--t2)] border border-[var(--b1)] hover:border-[var(--b2)] hover:text-[var(--t1)] transition-all"
          >
            Connexion
          </button>
          <button 
            onClick={onRegister}
            className="px-4 py-2 rounded-[20px] text-[13px] font-semibold btn-primary text-white transition-all hover:scale-[1.04]"
          >
            S&apos;inscrire
          </button>
        </div>
      </header>

      {/* Hero */}
      <section className="px-5 py-10 pb-7 text-center max-w-[600px] mx-auto">
        <div className="inline-flex items-center gap-[7px] bg-[var(--vio-g)] border border-[rgba(144,97,249,.3)] rounded-[20px] px-3.5 py-1.5 text-[11px] font-semibold text-[var(--vio)] mb-5">
          <span className="w-1.5 h-1.5 rounded-full bg-[var(--vio)] badge-pulse" />
          Assistant IA · Concours Camerounais
        </div>
        
        <h1 className="font-[var(--font-syne)] text-[clamp(26px,6.5vw,50px)] font-extrabold leading-[1.12] tracking-[-1px] text-[var(--t1)] mb-3.5">
          Réussis ton concours avec l&apos;<span className="gradient-text-hero">Intelligence Artificielle</span>
        </h1>
        
        <p className="text-[clamp(13px,3.5vw,16px)] text-[var(--t2)] leading-[1.65] mb-7">
          ENAM · FMSB · ENSP · ENS · ESSEC · IUT<br />
          L&apos;app qui <b className="text-[var(--cyn)]">entraîne, corrige et coache</b> comme un prof particulier.
        </p>
        
        <div className="flex flex-col items-center gap-2.5 mb-9 sm:flex-row sm:justify-center">
          <button 
            onClick={onRegister}
            className="flex items-center justify-center gap-2 px-7 py-3 btn-primary rounded-[25px] font-[var(--font-syne)] text-sm font-bold text-white w-full max-w-[300px] transition-all hover:-translate-y-0.5"
          >
            <span>🎓</span> Commencer gratuitement
          </button>
          <button 
            onClick={onLogin}
            className="px-5 py-3 bg-transparent border border-[var(--b1)] rounded-[25px] text-[13px] font-semibold text-[var(--t2)] w-full max-w-[260px] hover:border-[var(--b2)] hover:text-[var(--t1)] transition-all"
          >
            J&apos;ai déjà un compte
          </button>
        </div>

        {/* Preview Frame */}
        <PreviewFrame />
      </section>

      {/* Features */}
      <FeaturesSection />

      {/* Footer */}
      <footer className="px-5 py-6 border-t border-[var(--b0)] flex items-center justify-between flex-wrap gap-2 text-[11px] text-[var(--t3)]">
        <span>© 2026 Prépas Concours AI — Cameroun</span>
        <span>Made with ❤️ pour les candidats</span>
      </footer>
    </div>
  )
}

function PreviewFrame() {
  return (
    <div className="w-full max-w-[560px] mx-auto px-5">
      <div className="bg-[var(--surf)] border border-[var(--b1)] rounded-[16px] overflow-hidden shadow-[0_0_60px_rgba(91,110,245,.2)]">
        {/* Browser Bar */}
        <div className="flex items-center gap-[7px] px-3.5 py-2.5 border-b border-[var(--b0)] bg-[var(--bg2)]">
          <div className="flex gap-1">
            <div className="w-[9px] h-[9px] rounded-full bg-[#FF5F57]" />
            <div className="w-[9px] h-[9px] rounded-full bg-[#FEBC2E]" />
            <div className="w-[9px] h-[9px] rounded-full bg-[#28C840]" />
          </div>
          <div className="flex-1 bg-[var(--bg3)] rounded-[6px] px-2.5 py-1 text-[10px] text-[var(--t3)] flex items-center gap-[5px]">
            <span className="w-[7px] h-[7px] rounded-full bg-[var(--grn)]" />
            concourspro.cm
          </div>
        </div>
        
        {/* Content */}
        <div className="p-3.5">
          <div className="grid grid-cols-4 gap-1.5 mb-2.5">
            {[
              { value: "247", label: "Questions", color: "var(--ind2)" },
              { value: "72%", label: "Score", color: "var(--cyn)" },
              { value: "8", label: "Épreuves", color: "var(--vio)" },
              { value: "14h", label: "Révision", color: "var(--amb)" },
            ].map((stat, i) => (
              <div key={i} className="bg-[var(--bg3)] rounded-[8px] p-2 text-center">
                <span className="font-[var(--font-syne)] text-[15px] font-extrabold block" style={{ color: stat.color }}>
                  {stat.value}
                </span>
                <span className="text-[8px] text-[var(--t3)]">{stat.label}</span>
              </div>
            ))}
          </div>
          
          <div className="bg-[var(--bg3)] rounded-[10px] p-2.5">
            <div className="px-2.5 py-[7px] rounded-[9px] text-[10px] mb-1.5 max-w-[85%] ml-auto bg-gradient-to-r from-[var(--ind)] to-[var(--cyn)] text-white">
              Comment résoudre les équations différentielles ?
            </div>
            <div className="px-2.5 py-[7px] rounded-[9px] text-[10px] max-w-[85%] bg-[var(--bg2)] text-[var(--t2)] border border-[var(--b0)]">
              Je t&apos;explique la méthode en 3 étapes avec un exemple ENAM 2024...
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function FeaturesSection() {
  const features = [
    { title: "Professeur IA", desc: "Pose tes questions 24h/24 et reçois des explications adaptées à ton niveau.", color: "c1", icon: "💬" },
    { title: "Corrections Personnalisées", desc: "L'IA analyse tes erreurs et te donne des feedbacks détaillés.", color: "c2", icon: "✍️" },
    { title: "Planning Intelligent", desc: "Un programme de révision adapté à ta date de concours.", color: "c3", icon: "📅" },
    { title: "Examens Blancs", desc: "Chaque dimanche, un concours blanc avec classement national.", color: "c4", icon: "📝" },
    { title: "Mode Offline", desc: "Révise même sans connexion grâce à l'application PWA.", color: "c5", icon: "📱" },
    { title: "Statistiques Détaillées", desc: "Visualise ta progression par matière et identifie tes faiblesses.", color: "c6", icon: "📊" },
  ]

  const gradients: Record<string, string> = {
    c1: "linear-gradient(90deg, var(--ind), var(--cyn))",
    c2: "linear-gradient(90deg, var(--cyn), var(--grn))",
    c3: "linear-gradient(90deg, var(--vio), var(--ros))",
    c4: "linear-gradient(90deg, var(--amb), var(--ros))",
    c5: "linear-gradient(90deg, var(--grn), var(--cyn))",
    c6: "linear-gradient(90deg, var(--ind), var(--vio))",
  }

  const bgColors: Record<string, string> = {
    c1: "var(--ind-g)",
    c2: "var(--cyn-g)",
    c3: "var(--vio-g)",
    c4: "var(--amb-g)",
    c5: "rgba(15,227,163,.12)",
    c6: "var(--ind-g)",
  }

  return (
    <section className="px-5 py-12 max-w-[700px] mx-auto">
      <p className="text-[11px] font-semibold text-[var(--cyn)] tracking-[.1em] uppercase mb-2.5 text-center">
        Fonctionnalités
      </p>
      <h2 className="font-[var(--font-syne)] text-[clamp(22px,5vw,34px)] font-extrabold tracking-[-0.5px] text-[var(--t1)] text-center mb-8">
        Tout ce qu&apos;il te faut pour réussir
      </h2>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {features.map((feature, i) => (
          <div 
            key={i}
            className="bg-[var(--surf)] border border-[var(--b0)] rounded-[16px] p-5 transition-all relative overflow-hidden hover:border-[var(--b1)] hover:-translate-y-[3px]"
          >
            <div 
              className="absolute top-0 left-0 right-0 h-[2px] opacity-60"
              style={{ background: gradients[feature.color] }}
            />
            <div 
              className="w-10 h-10 rounded-[11px] flex items-center justify-center mb-3 text-lg"
              style={{ background: bgColors[feature.color] }}
            >
              {feature.icon}
            </div>
            <h3 className="font-[var(--font-syne)] text-sm font-bold text-[var(--t1)] mb-1.5">
              {feature.title}
            </h3>
            <p className="text-xs text-[var(--t2)] leading-[1.6]">
              {feature.desc}
            </p>
          </div>
        ))}
      </div>
    </section>
  )
}
