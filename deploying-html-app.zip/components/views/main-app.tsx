"use client"

import { useState } from "react"
import { Sidebar } from "@/components/app/sidebar"
import { TopBar } from "@/components/app/top-bar"
import { HomePane } from "@/components/app/panes/home-pane"
import { ChatPane } from "@/components/app/panes/chat-pane"
import { PlanningPane } from "@/components/app/panes/planning-pane"
import { ExamsPane } from "@/components/app/panes/exams-pane"
import { LeaderboardPane } from "@/components/app/panes/leaderboard-pane"
import { StatsPane } from "@/components/app/panes/stats-pane"
import { ProfilePanel } from "@/components/app/profile-panel"
import { UpgradeModal } from "@/components/app/upgrade-modal"
import { TimerPopup } from "@/components/app/timer-popup"

export type AppPane = "home" | "chat" | "coach" | "concours" | "planning" | "projects" | "contest" | "exams" | "leaderboard" | "stats" | "subscription" | "admin"

interface MainAppProps {
  isDark: boolean
  toggleTheme: () => void
}

export function MainApp({ isDark, toggleTheme }: MainAppProps) {
  const [currentPane, setCurrentPane] = useState<AppPane>("home")
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [profileOpen, setProfileOpen] = useState(false)
  const [modalOpen, setModalOpen] = useState(false)
  const [timerOpen, setTimerOpen] = useState(false)
  const [timerSeconds, setTimerSeconds] = useState(25 * 60)
  const [timerRunning, setTimerRunning] = useState(false)

  const paneNames: Record<AppPane, string> = {
    home: "Accueil",
    chat: "Professeur IA",
    coach: "Coach Méthodes",
    concours: "Épreuves",
    planning: "Planning",
    projects: "Projets",
    contest: "Mode Concours",
    exams: "Examens Blancs",
    leaderboard: "Classement",
    stats: "Statistiques",
    subscription: "Mon Abonnement",
    admin: "Admin Dashboard",
  }

  return (
    <div className="fixed inset-0 z-10 flex flex-col">
      {/* PWA Banner */}
      <PWABanner />

      <div className="flex-1 flex overflow-hidden min-h-0 relative">
        {/* Sidebar Overlay */}
        {sidebarOpen && (
          <div 
            className="absolute inset-0 bg-black/60 z-[199] backdrop-blur-[4px] md:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Sidebar */}
        <Sidebar 
          currentPane={currentPane}
          setCurrentPane={(pane) => { setCurrentPane(pane); setSidebarOpen(false) }}
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          onOpenProfile={() => setProfileOpen(true)}
          onOpenModal={() => setModalOpen(true)}
          isDark={isDark}
          toggleTheme={toggleTheme}
        />

        {/* Main Area */}
        <main className="flex-1 min-w-0 flex flex-col h-full overflow-hidden">
          {/* Mobile Topbar */}
          <TopBar 
            title={paneNames[currentPane]}
            currentPane={currentPane}
            onMenuClick={() => setSidebarOpen(true)}
            onTimerClick={() => setTimerOpen(!timerOpen)}
            onUpgradeClick={() => setModalOpen(true)}
            timerSeconds={timerSeconds}
            timerRunning={timerRunning}
            isMobile
          />
          
          {/* Desktop Topbar */}
          <TopBar 
            title={paneNames[currentPane]}
            currentPane={currentPane}
            onMenuClick={() => setSidebarOpen(true)}
            onTimerClick={() => setTimerOpen(!timerOpen)}
            onUpgradeClick={() => setModalOpen(true)}
            timerSeconds={timerSeconds}
            timerRunning={timerRunning}
          />

          {/* Panes */}
          <div className="flex-1 overflow-hidden">
            {currentPane === "home" && <HomePane onNavigate={setCurrentPane} onOpenModal={() => setModalOpen(true)} />}
            {currentPane === "chat" && <ChatPane />}
            {currentPane === "coach" && <ChatPane />}
            {currentPane === "planning" && <PlanningPane />}
            {currentPane === "exams" && <ExamsPane />}
            {currentPane === "leaderboard" && <LeaderboardPane />}
            {currentPane === "stats" && <StatsPane />}
            {(currentPane === "concours" || currentPane === "projects" || currentPane === "contest" || currentPane === "subscription" || currentPane === "admin") && (
              <HomePane onNavigate={setCurrentPane} onOpenModal={() => setModalOpen(true)} />
            )}
          </div>
        </main>
      </div>

      {/* Profile Panel */}
      <ProfilePanel 
        isOpen={profileOpen}
        onClose={() => setProfileOpen(false)}
        isDark={isDark}
        toggleTheme={toggleTheme}
      />

      {/* Upgrade Modal */}
      <UpgradeModal 
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
      />

      {/* Timer Popup */}
      <TimerPopup 
        isOpen={timerOpen}
        onClose={() => setTimerOpen(false)}
        seconds={timerSeconds}
        setSeconds={setTimerSeconds}
        running={timerRunning}
        setRunning={setTimerRunning}
      />
    </div>
  )
}

function PWABanner() {
  const [visible, setVisible] = useState(true)

  if (!visible) return null

  return (
    <div className="shrink-0 flex items-center gap-2.5 px-4 py-2.5 bg-gradient-to-r from-[rgba(91,110,245,.15)] to-[rgba(24,224,203,.1)] border-b border-[rgba(91,110,245,.25)] animate-[cardIn_0.5s_ease_both] relative z-10">
      <span className="text-xl shrink-0">📱</span>
      <div className="flex-1">
        <div className="text-[12.5px] font-bold text-[var(--t1)]">Les élèves sérieux installent l&apos;application</div>
        <div className="text-[10.5px] text-[var(--t2)]">Accès hors connexion · Depuis ton écran d&apos;accueil</div>
      </div>
      <button className="py-[7px] px-3.5 btn-primary rounded-[20px] text-[11.5px] font-bold text-white shrink-0 whitespace-nowrap hover:scale-[1.04] transition-all">
        Installer
      </button>
      <button 
        onClick={() => setVisible(false)}
        className="w-6 h-6 bg-transparent border border-[var(--b1)] rounded-[6px] text-[var(--t3)] text-[13px] flex items-center justify-center shrink-0 hover:border-[var(--b2)] hover:text-[var(--t1)] transition-all"
      >
        ✕
      </button>
    </div>
  )
}
