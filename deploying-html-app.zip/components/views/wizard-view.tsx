"use client"

import { useState } from "react"
import { Check } from "lucide-react"

interface WizardViewProps {
  onComplete: () => void
}

const wizardSteps = [
  {
    question: "Date de ton concours ?",
    hint: "Permet de calculer ton planning exact.",
    type: "input" as const,
    placeholder: "Ex : 15 Juillet 2026",
  },
  {
    question: "Heures disponibles par jour ?",
    hint: "Sois réaliste pour un planning efficace.",
    type: "options" as const,
    options: ["1–2 heures", "2–4 heures", "4–6 heures", "6h et plus"],
  },
  {
    question: "Jours disponibles ?",
    hint: "Évite les jours où tu es indisponible.",
    type: "options" as const,
    options: ["Tous les jours", "Lun–Ven", "Week-ends", "Variable"],
  },
  {
    question: "Ton niveau actuel ?",
    hint: "L'IA adapte la difficulté en conséquence.",
    type: "options" as const,
    options: ["Débutant", "Intermédiaire", "Avancé", "Expert"],
  },
  {
    question: "Ta plus grande difficulté ?",
    hint: "Le Coach adapte ses conseils dès le 1er jour.",
    type: "options" as const,
    options: ["Manque de méthode", "Mémorisation", "Gestion du temps", "Stress & motivation"],
  },
]

export function WizardView({ onComplete }: WizardViewProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [answers, setAnswers] = useState<(string | number)[]>([])

  const step = wizardSteps[currentStep]
  const isLastStep = currentStep === wizardSteps.length - 1

  const handleNext = () => {
    if (isLastStep) {
      onComplete()
    } else {
      setCurrentStep(currentStep + 1)
    }
  }

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleOptionSelect = (index: number) => {
    const newAnswers = [...answers]
    newAnswers[currentStep] = index
    setAnswers(newAnswers)
  }

  const handleInputChange = (value: string) => {
    const newAnswers = [...answers]
    newAnswers[currentStep] = value
    setAnswers(newAnswers)
  }

  return (
    <div className="fixed inset-0 z-10 flex flex-col items-center justify-center p-4 overflow-y-auto">
      <div className="w-full max-w-[500px] bg-[var(--surf)] border border-[var(--b1)] rounded-[20px] p-6 shadow-[0_20px_60px_rgba(0,0,0,.15)] card-animate">
        {/* Progress */}
        <div className="flex items-center gap-0 mb-6">
          {wizardSteps.map((_, index) => (
            <div key={index} className="flex items-center flex-1 last:flex-none">
              <div 
                className={`w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-bold shrink-0 border-2 transition-all ${
                  index < currentStep 
                    ? "bg-[var(--cyn)] border-[var(--cyn)] text-black" 
                    : index === currentStep 
                      ? "bg-[var(--ind-g)] border-[var(--ind)] text-[var(--ind2)]"
                      : "bg-[var(--bg3)] border-[var(--b1)] text-[var(--t3)]"
                }`}
              >
                {index < currentStep ? <Check size={14} /> : index + 1}
              </div>
              {index < wizardSteps.length - 1 && (
                <div 
                  className={`flex-1 h-0.5 ${
                    index < currentStep 
                      ? "bg-gradient-to-r from-[var(--cyn)] to-[var(--ind)]" 
                      : "bg-[var(--b1)]"
                  }`}
                />
              )}
            </div>
          ))}
        </div>

        {/* Question */}
        <h2 className="font-[var(--font-syne)] text-[17px] font-bold text-[var(--t1)] mb-1">
          {step.question}
        </h2>
        <p className="text-xs text-[var(--t2)] mb-4 leading-[1.5]">
          {step.hint}
        </p>

        {/* Content */}
        {step.type === "input" ? (
          <input 
            type="text"
            value={(answers[currentStep] as string) || ""}
            onChange={(e) => handleInputChange(e.target.value)}
            placeholder={step.placeholder}
            className="w-full bg-[var(--bg3)] border border-[var(--b1)] rounded-[10px] px-3 py-2.5 text-[13px] text-[var(--t1)] outline-none transition-all focus:border-[var(--ind)] focus:shadow-[0_0_0_3px_var(--ind-g)] placeholder:text-[var(--t3)] mb-4"
          />
        ) : (
          <div className="grid grid-cols-2 gap-2 mb-4">
            {step.options?.map((option, index) => (
              <button
                key={index}
                onClick={() => handleOptionSelect(index)}
                className={`py-2.5 px-3 rounded-[10px] text-center text-xs font-semibold transition-all border-[1.5px] ${
                  answers[currentStep] === index
                    ? "border-[var(--cyn)] text-[var(--t1)] bg-[rgba(24,224,203,.1)]"
                    : "bg-[var(--bg3)] border-[var(--b0)] text-[var(--t2)] hover:border-[var(--cyn)] hover:text-[var(--t1)] hover:bg-[rgba(24,224,203,.07)]"
                }`}
              >
                {option}
              </button>
            ))}
          </div>
        )}

        {/* Navigation */}
        <div className="flex gap-2">
          {currentStep > 0 && (
            <button 
              onClick={handlePrev}
              className="py-2.5 px-4 bg-transparent border border-[var(--b1)] rounded-[10px] text-[13px] font-semibold text-[var(--t2)] hover:border-[var(--b2)] hover:text-[var(--t1)] transition-all"
            >
              ← Préc.
            </button>
          )}
          <button 
            onClick={handleNext}
            className="flex-1 py-2.5 btn-primary rounded-[10px] font-[var(--font-syne)] text-[13px] font-bold text-white transition-all hover:scale-[1.02]"
          >
            {isLastStep ? "✓ Créer mon planning" : "Suivant →"}
          </button>
        </div>
      </div>
    </div>
  )
}
