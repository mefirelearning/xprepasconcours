"use client"

import { useState } from "react"
import { LogoMark } from "@/components/ui/logo"
import { ArrowLeft, Lock } from "lucide-react"

interface AuthViewProps {
  mode: "login" | "register"
  setMode: (mode: "login" | "register") => void
  onBack: () => void
  onSuccess: () => void
}

export function AuthView({ mode, setMode, onBack, onSuccess }: AuthViewProps) {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [phone, setPhone] = useState("")
  const [fullName, setFullName] = useState("")
  const [concours, setConcours] = useState("")
  const [niveau, setNiveau] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSuccess()
  }

  return (
    <div className="fixed inset-0 z-10 flex items-center justify-center p-4 overflow-y-auto">
      <div className="w-full max-w-[420px] bg-[var(--surf)] border border-[var(--b1)] rounded-[20px] p-7 shadow-[0_20px_60px_rgba(0,0,0,.15)] card-animate">
        {/* Back Button */}
        <button 
          onClick={onBack}
          className="inline-flex items-center gap-[5px] text-xs text-[var(--t3)] cursor-pointer mb-4 hover:text-[var(--t1)] transition-colors"
        >
          <ArrowLeft size={14} />
          Retour
        </button>

        {/* Logo */}
        <div className="flex items-center justify-center gap-2 mb-5">
          <LogoMark size={30} />
        </div>

        <h1 className="font-[var(--font-syne)] text-[22px] font-extrabold text-[var(--t1)] text-center mb-1">
          {mode === "login" ? "Content de te revoir 👋" : "Prêt à réussir ?"}
        </h1>
        <p className="text-[12.5px] text-[var(--t2)] text-center mb-5 leading-[1.5]">
          {mode === "login" 
            ? "Connecte-toi pour reprendre ta préparation" 
            : <>Rejoins <b className="text-[var(--cyn)]">+1 200 candidats</b> déjà inscrits</>
          }
        </p>

        {/* Tabs */}
        <div className="flex bg-[var(--bg3)] rounded-[10px] p-[3px] mb-5">
          <button 
            onClick={() => setMode("login")}
            className={`flex-1 py-2 rounded-[8px] text-center text-[13px] font-semibold transition-all ${
              mode === "login" 
                ? "bg-[var(--surf)] text-[var(--t1)] shadow-[0_2px_8px_rgba(0,0,0,.1)]" 
                : "text-[var(--t2)]"
            }`}
          >
            Connexion
          </button>
          <button 
            onClick={() => setMode("register")}
            className={`flex-1 py-2 rounded-[8px] text-center text-[13px] font-semibold transition-all ${
              mode === "register" 
                ? "bg-[var(--surf)] text-[var(--t1)] shadow-[0_2px_8px_rgba(0,0,0,.1)]" 
                : "text-[var(--t2)]"
            }`}
          >
            Inscription
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-3">
          {mode === "register" && (
            <>
              <div className="flex flex-col gap-1">
                <label className="text-[11.5px] font-semibold text-[var(--t2)]">Nom complet</label>
                <input 
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Ex : Jean-Pierre Mbarga"
                  className="bg-[var(--bg3)] border border-[var(--b1)] rounded-[10px] px-3 py-2.5 text-[13px] text-[var(--t1)] outline-none transition-all focus:border-[var(--ind)] focus:shadow-[0_0_0_3px_var(--ind-g)] placeholder:text-[var(--t3)]"
                />
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-[11.5px] font-semibold text-[var(--t2)]">Téléphone</label>
                <input 
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+237 6XX XXX XXX"
                  className="bg-[var(--bg3)] border border-[var(--b1)] rounded-[10px] px-3 py-2.5 text-[13px] text-[var(--t1)] outline-none transition-all focus:border-[var(--ind)] focus:shadow-[0_0_0_3px_var(--ind-g)] placeholder:text-[var(--t3)]"
                />
                <span className="text-[10.5px] text-[var(--t3)]">Pour recevoir le code OTP</span>
              </div>
            </>
          )}

          <div className="flex flex-col gap-1">
            <label className="text-[11.5px] font-semibold text-[var(--t2)]">Email</label>
            <input 
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="ton.email@exemple.cm"
              className="bg-[var(--bg3)] border border-[var(--b1)] rounded-[10px] px-3 py-2.5 text-[13px] text-[var(--t1)] outline-none transition-all focus:border-[var(--ind)] focus:shadow-[0_0_0_3px_var(--ind-g)] placeholder:text-[var(--t3)]"
            />
          </div>

          {mode === "register" && (
            <div className="grid grid-cols-2 gap-2.5">
              <div className="flex flex-col gap-1">
                <label className="text-[11.5px] font-semibold text-[var(--t2)]">Concours</label>
                <select 
                  value={concours}
                  onChange={(e) => setConcours(e.target.value)}
                  className="bg-[var(--bg3)] border border-[var(--b1)] rounded-[10px] px-3 py-2.5 text-[12.5px] text-[var(--t1)] outline-none transition-all focus:border-[var(--ind)] focus:shadow-[0_0_0_3px_var(--ind-g)] appearance-none cursor-pointer bg-[url('data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20width%3D%2712%27%20height%3D%2712%27%20viewBox%3D%270%200%2024%2024%27%20fill%3D%27none%27%20stroke%3D%27%238897BB%27%20stroke-width%3D%272%27%3E%3Cpath%20d%3D%27m6%209%206%206%206-6%27%2F%3E%3C%2Fsvg%3E')] bg-no-repeat bg-[right_11px_center]"
                >
                  <option value="" disabled>Choisir</option>
                  <option>ENAM</option>
                  <option>FMSB</option>
                  <option>ENSP</option>
                  <option>ENS</option>
                  <option>ESSEC</option>
                  <option>IUT</option>
                </select>
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-[11.5px] font-semibold text-[var(--t2)]">Niveau</label>
                <select 
                  value={niveau}
                  onChange={(e) => setNiveau(e.target.value)}
                  className="bg-[var(--bg3)] border border-[var(--b1)] rounded-[10px] px-3 py-2.5 text-[12.5px] text-[var(--t1)] outline-none transition-all focus:border-[var(--ind)] focus:shadow-[0_0_0_3px_var(--ind-g)] appearance-none cursor-pointer bg-[url('data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20width%3D%2712%27%20height%3D%2712%27%20viewBox%3D%270%200%2024%2024%27%20fill%3D%27none%27%20stroke%3D%27%238897BB%27%20stroke-width%3D%272%27%3E%3Cpath%20d%3D%27m6%209%206%206%206-6%27%2F%3E%3C%2Fsvg%3E')] bg-no-repeat bg-[right_11px_center]"
                >
                  <option value="" disabled>Choisir</option>
                  <option>Terminale</option>
                  <option>Post-Bac</option>
                  <option>Candidat libre</option>
                  <option>Redoublant</option>
                </select>
              </div>
            </div>
          )}

          <div className="flex flex-col gap-1">
            <label className="text-[11.5px] font-semibold text-[var(--t2)]">Mot de passe</label>
            <input 
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="8 caractères min."
              className="bg-[var(--bg3)] border border-[var(--b1)] rounded-[10px] px-3 py-2.5 text-[13px] text-[var(--t1)] outline-none transition-all focus:border-[var(--ind)] focus:shadow-[0_0_0_3px_var(--ind-g)] placeholder:text-[var(--t3)]"
            />
            {mode === "register" && (
              <span className="text-[10.5px] text-[var(--t3)]">Min. 8 car. · 1 majuscule · 1 chiffre</span>
            )}
          </div>

          <button 
            type="submit"
            className="w-full py-3 btn-primary rounded-[12px] font-[var(--font-syne)] text-sm font-bold text-white mt-1 transition-all hover:scale-[1.02]"
          >
            {mode === "login" ? "Se connecter →" : "Créer mon compte →"}
          </button>

          <div className="flex items-center gap-2.5 text-[11.5px] text-[var(--t3)]">
            <span className="flex-1 h-px bg-[var(--b1)]" />
            ou
            <span className="flex-1 h-px bg-[var(--b1)]" />
          </div>

          <button 
            type="button"
            onClick={onSuccess}
            className="w-full py-2.5 bg-[var(--bg3)] border border-[var(--b1)] rounded-[12px] text-[13px] font-semibold text-[var(--t1)] flex items-center justify-center gap-2 hover:border-[var(--b2)] transition-all"
          >
            <svg width="16" height="16" viewBox="0 0 24 24">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            Google
          </button>

          <p className="text-[11px] text-[var(--t3)] text-center mt-3 leading-[1.5]">
            En t&apos;inscrivant tu acceptes nos <span className="text-[var(--ind2)] cursor-pointer">CGU</span> et <span className="text-[var(--ind2)] cursor-pointer">Politique de confidentialité</span>.
          </p>
        </form>

        {/* Security Badge */}
        <div className="flex items-center justify-center gap-[7px] p-2 bg-[rgba(15,227,163,.06)] border border-[rgba(15,227,163,.2)] rounded-[9px] text-[11px] text-[var(--grn)] mt-3.5 font-medium">
          <Lock size={12} />
          OTP SMS · SSL · Anti-spam · Données chiffrées
        </div>
      </div>
    </div>
  )
}
