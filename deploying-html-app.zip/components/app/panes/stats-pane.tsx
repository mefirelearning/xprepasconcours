"use client"

export function StatsPane() {
  const progressData = [
    {
      name: "ENAM — Culture Générale",
      percentage: 67,
      color: "a",
      chips: [
        { label: "Droit Civil", status: "ok" },
        { label: "Histoire", status: "mid" },
        { label: "Institutions", status: "low" },
      ],
    },
    {
      name: "FMSB — Sciences",
      percentage: 54,
      color: "b",
      chips: [
        { label: "Physique", status: "ok" },
        { label: "Chimie", status: "low" },
        { label: "SVT", status: "mid" },
      ],
    },
    {
      name: "Mathématiques",
      percentage: 81,
      color: "c",
      chips: [
        { label: "Analyse", status: "ok" },
        { label: "Algèbre", status: "ok" },
        { label: "Probas", status: "mid" },
      ],
    },
  ]

  const colorMap: Record<string, { text: string; fill: string }> = {
    a: { text: "var(--ind2)", fill: "linear-gradient(90deg, var(--ind), var(--cyn))" },
    b: { text: "var(--cyn)", fill: "linear-gradient(90deg, var(--cyn), var(--vio))" },
    c: { text: "var(--vio)", fill: "linear-gradient(90deg, var(--vio), var(--ros))" },
  }

  const chipColors: Record<string, { bg: string; color: string; icon: string }> = {
    ok: { bg: "rgba(15,227,163,.12)", color: "var(--grn)", icon: "✓" },
    mid: { bg: "var(--amb-g)", color: "var(--amb)", icon: "⟳" },
    low: { bg: "var(--ros-g)", color: "var(--ros)", icon: "!" },
  }

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-5 max-w-[980px]">
      <div className="flex items-center justify-between mb-3">
        <span className="text-[10px] font-bold text-[var(--t3)] tracking-[.1em] uppercase">
          Progression par matière
        </span>
      </div>

      <div className="space-y-3">
        {progressData.map((item, i) => (
          <div
            key={i}
            className="bg-[var(--surf)] border border-[var(--b0)] rounded-[14px] p-4"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="text-sm font-bold text-[var(--t1)]">{item.name}</div>
              <div
                className="font-[var(--font-syne)] text-lg font-extrabold"
                style={{ color: colorMap[item.color].text }}
              >
                {item.percentage}%
              </div>
            </div>

            <div className="h-2 bg-[var(--bg3)] rounded-full overflow-hidden mb-3">
              <div
                className="h-full rounded-full progress-animate"
                style={{
                  width: `${item.percentage}%`,
                  background: colorMap[item.color].fill,
                }}
              />
            </div>

            <div className="flex flex-wrap gap-1.5">
              {item.chips.map((chip, j) => (
                <span
                  key={j}
                  className="text-[10px] font-semibold py-1 px-2 rounded-[20px] flex items-center gap-1"
                  style={{
                    background: chipColors[chip.status].bg,
                    color: chipColors[chip.status].color,
                  }}
                >
                  <span>{chipColors[chip.status].icon}</span>
                  {chip.label}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Weekly Stats */}
      <div className="mt-4">
        <div className="flex items-center justify-between mb-3">
          <span className="text-[10px] font-bold text-[var(--t3)] tracking-[.1em] uppercase">
            Cette semaine
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          {[
            { label: "Temps de révision", value: "14h 32min", icon: "⏱️" },
            { label: "Questions posées", value: "47", icon: "💬" },
            { label: "Exercices complétés", value: "23", icon: "✍️" },
            { label: "Score moyen", value: "72%", icon: "🎯" },
          ].map((stat, i) => (
            <div
              key={i}
              className="bg-[var(--surf)] border border-[var(--b0)] rounded-[12px] p-3 flex items-center gap-2.5"
            >
              <span className="text-xl">{stat.icon}</span>
              <div className="min-w-0">
                <div className="font-[var(--font-syne)] text-base font-bold text-[var(--t1)]">
                  {stat.value}
                </div>
                <div className="text-[9px] text-[var(--t3)]">{stat.label}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recommendations */}
      <div className="mt-4">
        <div className="flex items-center justify-between mb-3">
          <span className="text-[10px] font-bold text-[var(--t3)] tracking-[.1em] uppercase">
            Recommandations IA
          </span>
        </div>

        <div className="bg-gradient-to-br from-[rgba(68,82,217,.08)] to-[rgba(11,173,155,.06)] border border-[rgba(68,82,217,.2)] rounded-[14px] p-4">
          <div className="text-sm font-bold text-[var(--ind)] mb-3 flex items-center gap-2">
            <span>💡</span>
            Basé sur tes 8 dernières sessions
          </div>

          <div className="space-y-2">
            {[
              "Consacre 2h supplémentaires aux Institutions du Cameroun cette semaine.",
              "Tes performances en Mathématiques sont excellentes — maintiens ce rythme !",
              "Essaie de faire au moins 3 épreuves type avant le concours blanc de dimanche.",
            ].map((rec, i) => (
              <div
                key={i}
                className="flex items-start gap-2 p-2 bg-[var(--bg2)] rounded-[8px] border border-[var(--b0)]"
              >
                <span className="w-5 h-5 rounded-full bg-gradient-to-br from-[var(--ind)] to-[var(--cyn)] text-white text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                  {i + 1}
                </span>
                <span className="text-xs text-[var(--t1)]">{rec}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
