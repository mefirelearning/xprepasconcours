"use client"

import type { AppPane } from "@/components/views/main-app"
import { Calendar, HelpCircle, RefreshCw } from "lucide-react"
import { useState } from "react"

interface HomePaneProps {
  onNavigate: (pane: AppPane) => void
  onOpenModal: () => void
}

export function HomePane({ onNavigate, onOpenModal }: HomePaneProps) {
  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-5 max-w-[980px]">
      {/* Expiration Alert */}
      <ExpirationAlert onOpenModal={onOpenModal} />
      
      {/* Exam Reminder */}
      <ExamReminder />
      
      {/* Welcome Card */}
      <WelcomeCard />
      
      {/* Rank Card */}
      <RankCard />
      
      {/* Stats Grid */}
      <StatsGrid />
      
      {/* Weakness Card */}
      <WeaknessCard onNavigate={onNavigate} />
      
      {/* Two Column Layout */}
      <div className="grid grid-cols-1 md:grid-cols-[1.2fr_1fr] gap-3.5 mb-4">
        <PlanningCard onNavigate={onNavigate} />
        <div className="flex flex-col gap-3">
          <QuoteCard />
          <MusicCard />
        </div>
      </div>
    </div>
  )
}

function ExpirationAlert({ onOpenModal }: { onOpenModal: () => void }) {
  const [visible, setVisible] = useState(true)
  
  if (!visible) return null
  
  return (
    <div className="flex items-start gap-3 p-3.5 bg-[rgba(225,75,122,.09)] border border-[rgba(225,75,122,.35)] rounded-[12px] mb-3.5 animate-[cardIn_0.4s_cubic-bezier(.34,1.2,.64,1)]">
      <span className="text-xl shrink-0 mt-0.5">⚠️</span>
      <div className="flex-1 min-w-0">
        <div className="text-[13px] font-bold text-[var(--t1)] mb-[3px]">Votre abonnement MASTERY expire demain</div>
        <div className="text-[11.5px] text-[var(--t2)] leading-[1.55]">
          Vos données premium seront verrouillées. Renouvelez maintenant pour ne pas perdre votre progression.
        </div>
        <button 
          onClick={onOpenModal}
          className="inline-flex items-center gap-[5px] mt-2 py-[7px] px-3.5 rounded-[20px] text-[11.5px] font-bold bg-gradient-to-br from-[var(--ros)] to-[var(--vio)] text-white shadow-[0_4px_12px_rgba(225,75,122,.3)] hover:scale-[1.04] transition-all"
        >
          Renouveler — 2 500 F/mois
        </button>
      </div>
      <button 
        onClick={() => setVisible(false)}
        className="w-6 h-6 shrink-0 bg-transparent border border-[var(--b1)] rounded-[6px] text-xs text-[var(--t3)] flex items-center justify-center hover:border-[var(--b2)] hover:text-[var(--t1)] transition-all mt-0.5"
      >
        ✕
      </button>
    </div>
  )
}

function ExamReminder() {
  return (
    <div className="flex items-center gap-2.5 p-3 bg-[rgba(68,82,217,.07)] border border-[rgba(68,82,217,.25)] rounded-[12px] mb-3.5">
      <span className="text-lg shrink-0">⏰</span>
      <div className="flex-1 min-w-0">
        <div className="text-xs font-bold text-[var(--t1)]">Concours blanc ENAM demain à 13h00</div>
        <div className="text-[10.5px] text-[var(--t2)]">Durée 4h · Envoi des réponses avant 22h. Révisez les notions de la semaine.</div>
      </div>
    </div>
  )
}

function WelcomeCard() {
  return (
    <div className="flex items-center gap-3.5 bg-gradient-to-br from-[var(--surf)] to-[var(--surf2)] border border-[var(--b0)] rounded-[16px] p-4 mb-4 relative overflow-hidden welcome-glow">
      <div className="w-[46px] h-[46px] shrink-0 z-10 bg-gradient-to-br from-[var(--ind)] to-[var(--vio)] rounded-full flex items-center justify-center text-xl shadow-[0_5px_18px_rgba(144,97,249,.4)] relative aura-effect">
        🎓
      </div>
      <div className="flex-1 z-10 min-w-0">
        <div className="text-[11.5px] text-[var(--t2)] mb-0.5">Bonne journée,</div>
        <div className="font-[var(--font-syne)] text-[clamp(17px,4.5vw,21px)] font-extrabold tracking-[-0.4px]">
          Mefire <span className="gradient-text">Fifen</span> 👋
        </div>
        <div className="text-[11.5px] text-[var(--t2)] mt-[3px]">
          ENAM dans <b className="text-[var(--cyn)] font-mono">87 jours</b> · Continue !
        </div>
      </div>
      <div className="z-10 flex items-center gap-[7px] shrink-0 bg-[rgba(245,166,35,.1)] border border-[rgba(245,166,35,.3)] rounded-[11px] py-2 px-3">
        <span className="text-xl streak-flame">🔥</span>
        <div>
          <div className="font-[var(--font-syne)] text-[15px] font-extrabold text-[var(--amb)]">×7</div>
          <div className="text-[8.5px] text-[var(--t3)] uppercase">streak</div>
        </div>
      </div>
    </div>
  )
}

function RankCard() {
  return (
    <div className="bg-gradient-to-br from-[var(--surf)] to-[var(--surf2)] border border-[var(--b0)] rounded-[14px] p-4 mb-4 relative overflow-hidden">
      <div className="absolute top-[-40%] right-[-8%] w-[180px] h-[180px] bg-[radial-gradient(circle,rgba(144,97,249,.1),transparent_60%)] pointer-events-none" />
      <div className="flex items-center gap-2.5 mb-3 relative">
        <div className="w-[38px] h-[38px] shrink-0 bg-gradient-to-br from-[var(--vio)] to-[var(--cyn)] rounded-[10px] flex items-center justify-center text-lg shadow-[0_4px_12px_rgba(144,97,249,.35)]">
          ⚡
        </div>
        <div>
          <div className="text-[9px] text-[var(--t3)] uppercase tracking-[.05em]">Niveau actuel</div>
          <div className="font-[var(--font-syne)] text-lg font-extrabold gradient-text">SÉRIEUX → CONFIRMÉ</div>
        </div>
      </div>
      <div className="h-[7px] bg-[var(--bg3)] rounded-[10px] overflow-hidden mb-[7px]">
        <div className="h-full w-[62%] bg-gradient-to-r from-[var(--cyn)] via-[var(--vio)] to-[var(--ros)] rounded-[10px] progress-animate relative">
          <div className="absolute top-0 right-0 w-[30%] h-full bg-gradient-to-r from-transparent to-white/40 animate-[pulse_2.5s_ease-in-out_infinite]" />
        </div>
      </div>
      <div className="flex justify-between text-[10.5px]">
        <span className="text-[var(--cyn)] font-bold">2 480 / 4 000 XP</span>
        <span className="text-[var(--t3)]">Prochain : <b className="text-[var(--vio)]">CONFIRMÉ</b></span>
      </div>
    </div>
  )
}

function StatsGrid() {
  const stats = [
    { icon: "💬", value: "247", label: "Questions", color: "a" },
    { icon: "🎯", value: "72%", label: "Score", color: "b" },
    { icon: "📄", value: "8", label: "Épreuves", color: "c" },
    { icon: "⏱️", value: "14h", label: "Révision", color: "d" },
  ]
  
  const colorClasses: Record<string, string> = {
    a: "bg-gradient-to-br from-[var(--ind)] to-[var(--cyn)] bg-clip-text text-transparent",
    b: "text-[var(--cyn)]",
    c: "text-[var(--vio)]",
    d: "text-[var(--amb)]",
  }
  
  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-4">
      {stats.map((stat, i) => (
        <div key={i} className="bg-[var(--surf)] border border-[var(--b0)] rounded-[13px] p-3.5 transition-all relative overflow-hidden hover:border-[var(--b1)]">
          <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-[var(--cyn)] to-transparent opacity-40" />
          <span className="text-lg block mb-[7px]">{stat.icon}</span>
          <span className={`font-[var(--font-syne)] text-[clamp(20px,5vw,26px)] font-extrabold block leading-none mb-0.5 ${colorClasses[stat.color]}`}>
            {stat.value}
          </span>
          <span className="text-[9.5px] text-[var(--t3)] uppercase tracking-[.05em]">{stat.label}</span>
        </div>
      ))}
    </div>
  )
}

function WeaknessCard({ onNavigate }: { onNavigate: (pane: AppPane) => void }) {
  return (
    <div className="bg-gradient-to-br from-[rgba(240,97,138,.08)] to-[rgba(144,97,249,.05)] border border-[rgba(240,97,138,.25)] rounded-[14px] p-4 mb-4">
      <div className="flex items-center gap-2.5 mb-2.5">
        <div className="w-[38px] h-[38px] shrink-0 bg-gradient-to-br from-[var(--ros)] to-[var(--vio)] rounded-[10px] flex items-center justify-center shadow-[0_4px_12px_rgba(240,97,138,.35)]">
          <HelpCircle size={18} className="text-white" />
        </div>
        <div>
          <div className="text-[13px] font-bold text-[var(--t1)]">Analyse intelligente de tes faiblesses</div>
          <div className="text-[10px] text-[var(--t3)]">8 dernières sessions</div>
        </div>
      </div>
      <div className="bg-[rgba(240,97,138,.08)] border border-[rgba(240,97,138,.3)] rounded-[10px] p-3">
        <div className="text-[12.5px] text-[var(--t1)] leading-[1.55]">
          <span className="font-[var(--font-syne)] text-base font-extrabold text-[var(--ros)] mr-1">73%</span>
          <b className="text-[var(--ros)]">de chances de perdre des points sur les Institutions</b> au prochain blanc ENAM.
        </div>
        <button 
          onClick={() => onNavigate("chat")}
          className="inline-flex items-center gap-[5px] mt-2 text-[11px] text-[var(--ros)] font-bold bg-[rgba(240,97,138,.12)] border border-[rgba(240,97,138,.3)] rounded-[20px] py-[5px] px-3 hover:bg-[var(--ros)] hover:text-white transition-all"
        >
          → Plan d&apos;action IA
        </button>
      </div>
    </div>
  )
}

function PlanningCard({ onNavigate }: { onNavigate: (pane: AppPane) => void }) {
  const tasks = [
    { title: "Histoire du Cameroun", time: "07:00 — 08:30", status: "done", tag: "FAIT", tagColor: "c" },
    { title: "Épreuve ENAM CG 2022", time: "09:00 — 11:00", status: "now", tag: "EN COURS", tagColor: "v" },
    { title: "Correction IA + fiche", time: "14:00 — 15:30", status: "", tag: "À VENIR", tagColor: "a" },
  ]
  
  const tagColors: Record<string, { bg: string; color: string }> = {
    c: { bg: "var(--cyn-g)", color: "var(--cyn)" },
    v: { bg: "var(--vio-g)", color: "var(--vio)" },
    a: { bg: "var(--amb-g)", color: "var(--amb)" },
  }
  
  return (
    <div className="bg-gradient-to-br from-[var(--surf)] to-[var(--surf2)] border border-[var(--b0)] rounded-[14px] p-4">
      <div className="flex items-center gap-2 mb-3">
        <div className="w-[34px] h-[34px] shrink-0 bg-gradient-to-br from-[var(--cyn)] to-[var(--vio)] rounded-[10px] flex items-center justify-center shadow-[0_4px_12px_rgba(24,224,203,.3)]">
          <Calendar size={17} className="text-white" />
        </div>
        <div>
          <div className="text-[13px] font-bold text-[var(--t1)]">Aujourd&apos;hui</div>
          <div className="text-[10px] text-[var(--t3)]">Lundi 6 mai · ENAM</div>
        </div>
      </div>
      
      {tasks.map((task, i) => (
        <div 
          key={i}
          className={`flex items-center gap-2 p-2 rounded-[9px] border mb-[7px] cursor-pointer transition-all ${
            task.status === "done" 
              ? "opacity-50 bg-[var(--bg3)] border-[var(--b0)]" 
              : task.status === "now" 
                ? "border-[var(--vio)] bg-[rgba(144,97,249,.05)]" 
                : "bg-[var(--bg3)] border-[var(--b0)] hover:border-[var(--cyn)]"
          }`}
        >
          <div className={`w-[17px] h-[17px] rounded-full border-2 flex items-center justify-center text-[8.5px] shrink-0 ${
            task.status === "done" 
              ? "bg-[var(--grn)] border-[var(--grn)] text-black" 
              : task.status === "now" 
                ? "border-[var(--b1)] text-[var(--vio)]" 
                : "border-[var(--b1)]"
          }`}>
            {task.status === "done" ? "✓" : task.status === "now" ? "●" : ""}
          </div>
          <div className="flex-1 min-w-0">
            <div className={`text-[11.5px] font-semibold ${task.status === "done" ? "line-through text-[var(--t3)]" : "text-[var(--t1)]"}`}>
              {task.title}
            </div>
            <div className="text-[9px] text-[var(--t3)]">{task.time}</div>
          </div>
          <span 
            className="text-[9px] font-bold py-0.5 px-[7px] rounded-[20px] shrink-0"
            style={{ background: tagColors[task.tagColor].bg, color: tagColors[task.tagColor].color }}
          >
            {task.tag}
          </span>
        </div>
      ))}
      
      <button 
        onClick={() => onNavigate("planning")}
        className="text-[11px] text-[var(--cyn)] text-center mt-1.5 w-full cursor-pointer hover:underline"
      >
        Planning complet →
      </button>
    </div>
  )
}

function QuoteCard() {
  const [quoteIndex, setQuoteIndex] = useState(0)
  
  const quotes = [
    { text: "\"Plus qu'une app de révision. Une intelligence d'entraînement pour les concours.\"", author: "Prépas Concours AI" },
    { text: "\"Le succès, c'est aller d'échec en échec sans perdre son enthousiasme.\"", author: "Winston Churchill" },
    { text: "\"L'éducation est l'arme la plus puissante pour changer le monde.\"", author: "Nelson Mandela" },
  ]
  
  const quote = quotes[quoteIndex]
  
  return (
    <div className="bg-gradient-to-br from-[var(--surf)] to-[var(--surf2)] border border-[var(--b0)] border-l-[3px] border-l-[var(--vio)] rounded-[13px] p-4 relative">
      <span className="absolute top-1 left-[11px] font-serif text-[42px] leading-none text-[var(--vio)] opacity-20">&quot;</span>
      <p className="text-xs text-[var(--t2)] italic leading-[1.6] my-1.5 pl-1">
        {quote.text}
      </p>
      <div className="text-[10px] text-[var(--vio)] font-semibold flex items-center gap-[5px]">
        <span className="w-[13px] h-px bg-[var(--vio)]" />
        {quote.author}
      </div>
      <button 
        onClick={() => setQuoteIndex((quoteIndex + 1) % quotes.length)}
        className="mt-2 inline-flex items-center gap-1 text-[10px] text-[var(--vio)] bg-[rgba(144,97,249,.1)] border border-[rgba(144,97,249,.2)] rounded-[20px] py-1 px-2.5 font-semibold hover:bg-[rgba(144,97,249,.2)] transition-all"
      >
        <RefreshCw size={10} />
        Nouvelle
      </button>
    </div>
  )
}

function MusicCard() {
  const [playing, setPlaying] = useState(false)
  
  return (
    <div 
      onClick={() => setPlaying(!playing)}
      className="bg-gradient-to-br from-[var(--surf)] to-[var(--surf2)] border border-[var(--b0)] rounded-[13px] p-3 flex items-center gap-2 cursor-pointer hover:border-[var(--b1)] transition-all"
    >
      <div className={`w-[34px] h-[34px] shrink-0 bg-gradient-to-br from-[#1A2E5F] to-[var(--cyn)] rounded-full flex items-center justify-center text-sm shadow-[0_4px_10px_rgba(24,224,203,.25)] ${playing ? "disc-spin" : ""}`}>
        🎵
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-xs font-bold text-[var(--t1)]">Musique focus</div>
        <div className="text-[10px] text-[var(--t3)]">
          {playing ? "En lecture · Lo-fi Focus" : "Appuie pour démarrer"}
        </div>
      </div>
      <div className="flex items-end gap-[3px] h-4">
        {[1, 2, 3, 4, 5].map((i) => (
          <div key={i} className={`wave-bar ${playing ? "active" : ""}`} />
        ))}
      </div>
    </div>
  )
}
