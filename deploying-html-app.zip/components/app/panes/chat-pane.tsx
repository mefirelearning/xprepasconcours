"use client"

import { useState, useRef, useEffect } from "react"
import { Send, Mic, Paperclip } from "lucide-react"

interface Message {
  id: string
  type: "user" | "bot"
  content: string
  isThinking?: boolean
}

const suggestions = [
  "Explique-moi la Constitution du Cameroun",
  "Comment résoudre une équation différentielle ?",
  "Aide-moi à préparer un plan de dissertation",
  "Quelles sont les matières à réviser en priorité pour ENAM ?",
]

const botResponses = [
  "Tu fais cette erreur parce que tu sautes l'étape clé du raisonnement. Voici l'astuce des correcteurs ENAM… 📖",
  "D'après tes 8 dernières sessions, tu perds des points sur l'application des concepts. Voici la méthode des lauréats. ✅",
  "Bonne question ! Voici la correction étape par étape selon le programme officiel camerounais. 🎯",
  "J'ai analysé toutes les épreuves ENAM 2015–2024. Ce type revient dans 67% des concours. 💡",
]

export function ChatPane() {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isMicActive, setIsMicActive] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSend = (text?: string) => {
    const messageText = text || input.trim()
    if (!messageText) return

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      type: "user",
      content: messageText,
    }

    const thinkingMessage: Message = {
      id: `thinking-${Date.now()}`,
      type: "bot",
      content: "",
      isThinking: true,
    }

    setMessages((prev) => [...prev, userMessage, thinkingMessage])
    setInput("")

    // Simulate AI response
    const delay = 2000 + Math.random() * 2000
    setTimeout(() => {
      const botResponse: Message = {
        id: `bot-${Date.now()}`,
        type: "bot",
        content: botResponses[Math.floor(Math.random() * botResponses.length)],
      }
      setMessages((prev) => prev.filter((m) => !m.isThinking).concat(botResponse))
    }, delay)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const autoResize = () => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto"
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 100)}px`
    }
  }

  const showEmpty = messages.length === 0

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Messages Area */}
      <div className={`flex-1 overflow-y-auto p-4 ${showEmpty ? "" : "pb-2"}`}>
        {showEmpty ? (
          <EmptyState onSuggestionClick={(text) => handleSend(text)} />
        ) : (
          <div className="max-w-[700px] mx-auto space-y-4">
            {messages.map((message) => (
              <MessageBubble key={message.id} message={message} />
            ))}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="shrink-0 p-4 pt-2 border-t border-[var(--b0)] bg-[var(--bg2)]">
        <div className="max-w-[700px] mx-auto">
          {showEmpty && (
            <div className="flex flex-wrap gap-2 mb-3">
              {suggestions.map((suggestion, i) => (
                <button
                  key={i}
                  onClick={() => handleSend(suggestion)}
                  className="text-[11px] py-1.5 px-3 bg-[var(--bg3)] border border-[var(--b0)] rounded-[20px] text-[var(--t2)] font-medium hover:border-[var(--cyn)] hover:text-[var(--cyn)] hover:bg-[var(--cyn-g)] transition-all"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          )}

          <div className="flex items-end gap-2 bg-[var(--surf)] border border-[var(--b1)] rounded-[16px] p-2">
            <label className="cursor-pointer shrink-0">
              <input type="file" className="hidden" />
              <Paperclip size={18} className="text-[var(--t3)] hover:text-[var(--t1)] transition-colors" />
            </label>

            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => {
                setInput(e.target.value)
                autoResize()
              }}
              onKeyDown={handleKeyDown}
              placeholder="Pose ta question au Professeur IA..."
              rows={1}
              className="flex-1 bg-transparent border-none outline-none resize-none text-[13px] text-[var(--t1)] placeholder:text-[var(--t3)] min-h-[24px] max-h-[100px]"
            />

            <button
              onClick={() => setIsMicActive(!isMicActive)}
              className={`shrink-0 w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                isMicActive
                  ? "bg-[var(--ros)] text-white"
                  : "bg-[var(--bg3)] text-[var(--t3)] hover:text-[var(--t1)]"
              }`}
            >
              <Mic size={16} />
            </button>

            <button
              onClick={() => handleSend()}
              disabled={!input.trim()}
              className="shrink-0 w-8 h-8 rounded-full flex items-center justify-center bg-gradient-to-br from-[var(--ind)] to-[var(--cyn)] text-white disabled:opacity-40 disabled:cursor-not-allowed hover:enabled:scale-105 transition-all"
            >
              <Send size={14} />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

function EmptyState({ onSuggestionClick }: { onSuggestionClick: (text: string) => void }) {
  return (
    <div className="h-full flex flex-col items-center justify-center text-center px-4">
      <div className="w-16 h-16 bg-gradient-to-br from-[var(--ind)] to-[var(--cyn)] rounded-full flex items-center justify-center text-2xl shadow-[0_8px_30px_rgba(91,110,245,.4)] mb-4">
        🤖
      </div>
      <h2 className="font-[var(--font-syne)] text-xl font-extrabold text-[var(--t1)] mb-2">
        Professeur IA
      </h2>
      <p className="text-sm text-[var(--t2)] max-w-[400px] mb-6">
        Pose-moi tes questions sur n&apos;importe quelle matière. Je t&apos;explique, je corrige et je te guide vers la réussite.
      </p>
      <div className="grid grid-cols-2 gap-2 max-w-[500px]">
        {suggestions.map((suggestion, i) => (
          <button
            key={i}
            onClick={() => onSuggestionClick(suggestion)}
            className="text-left text-xs p-3 bg-[var(--surf)] border border-[var(--b0)] rounded-[12px] text-[var(--t2)] hover:border-[var(--cyn)] hover:bg-[var(--cyn-g)] transition-all"
          >
            {suggestion}
          </button>
        ))}
      </div>
    </div>
  )
}

function MessageBubble({ message }: { message: Message }) {
  if (message.isThinking) {
    return (
      <div className="flex items-start gap-2">
        <div className="w-8 h-8 shrink-0 rounded-full flex items-center justify-center bg-gradient-to-br from-[var(--ind)] to-[var(--cyn)]">
          <svg className="think-spin" viewBox="0 0 100 100" width="20" height="20">
            <defs>
              <linearGradient id="thinkGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="var(--cyn)" />
                <stop offset="100%" stopColor="var(--vio)" />
              </linearGradient>
            </defs>
            <circle cx="50" cy="50" r="44" fill="none" stroke="url(#thinkGrad)" strokeWidth="3.5" strokeDasharray="55 30" opacity="0.9" />
          </svg>
        </div>
        <div className="flex items-center gap-2 py-2 px-3 bg-[var(--surf)] border border-[var(--b0)] rounded-[12px] rounded-tl-[4px]">
          <span className="text-xs text-[var(--t2)]">Réflexion…</span>
          <div className="flex gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-[var(--cyn)] typing-dot" />
            <span className="w-1.5 h-1.5 rounded-full bg-[var(--cyn)] typing-dot" />
            <span className="w-1.5 h-1.5 rounded-full bg-[var(--cyn)] typing-dot" />
          </div>
        </div>
      </div>
    )
  }

  if (message.type === "user") {
    return (
      <div className="flex items-start gap-2 justify-end">
        <div className="py-2 px-3 bg-gradient-to-br from-[var(--ind)] to-[var(--cyn)] text-white rounded-[12px] rounded-tr-[4px] max-w-[80%] text-[13px]">
          {message.content}
        </div>
        <div className="w-8 h-8 shrink-0 rounded-full flex items-center justify-center bg-gradient-to-br from-[var(--vio)] to-[var(--ros)] text-white text-xs font-bold">
          M
        </div>
      </div>
    )
  }

  return (
    <div className="flex items-start gap-2">
      <div className="w-8 h-8 shrink-0 rounded-full flex items-center justify-center bg-gradient-to-br from-[var(--ind)] to-[var(--cyn)]">
        <svg viewBox="0 0 100 100" width="20" height="20">
          <defs>
            <linearGradient id="botGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="var(--cyn)" />
              <stop offset="100%" stopColor="var(--vio)" />
            </linearGradient>
          </defs>
          <circle cx="50" cy="50" r="44" fill="none" stroke="url(#botGrad)" strokeWidth="3" strokeDasharray="55 30" opacity="0.9" />
          <text x="50" y="57" textAnchor="middle" fontSize="28" fontWeight="900" fill="url(#botGrad)" fontFamily="var(--font-syne), Syne, sans-serif">
            P
          </text>
        </svg>
      </div>
      <div className="py-2 px-3 bg-[var(--surf)] border border-[var(--b0)] rounded-[12px] rounded-tl-[4px] max-w-[80%] text-[13px] text-[var(--t1)]">
        {message.content}
      </div>
    </div>
  )
}
