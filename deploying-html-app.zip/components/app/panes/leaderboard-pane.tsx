"use client"

import { useState } from "react"

const lbTabs = ["ENAM", "FMSB", "ENS", "ENSP", "ESSEC", "IUT"]

const leaderboardData = [
  { pos: 1, initials: "AT", name: "Aïcha Tabi", plan: "EXCELLENCE", score: "18.5/20", change: "+1.5", up: true },
  { pos: 2, initials: "JM", name: "Junior Mbarga", plan: "ÉLITE", score: "17.0/20", change: "+0.5", up: true },
  { pos: 3, initials: "SE", name: "Sandrine Eboa", plan: "ÉLITE", score: "16.5/20", change: "-0.5", up: false },
  { pos: 4, initials: "EN", name: "Eric Nguelle", plan: "MASTERY", score: "15.5/20", change: "+2.0", up: true },
  { pos: 5, initials: "PM", name: "Parfait Manga", plan: "ÉLITE", score: "15.0/20", change: "+1.0", up: true },
  { pos: 23, initials: "MF", name: "Mefire Fifen", plan: "MASTERY", score: "14.5/20", change: "+2.0", up: true, isMe: true },
]

export function LeaderboardPane() {
  const [activeTab, setActiveTab] = useState("ENAM")

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-5 max-w-[980px]">
      {/* Welcome */}
      <div className="flex items-center gap-3.5 bg-gradient-to-br from-[var(--surf)] to-[var(--surf2)] border border-[var(--b0)] rounded-[16px] p-4 mb-3.5 relative overflow-hidden">
        <div className="w-[46px] h-[46px] shrink-0 bg-gradient-to-br from-[#D98412] to-[#7B47E0] rounded-full flex items-center justify-center text-xl shadow-[0_5px_18px_rgba(144,97,249,.4)]">
          🏆
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-[11.5px] text-[var(--t2)]">Classement après concours blanc — Dimanche 11 mai</div>
          <div className="font-[var(--font-syne)] text-lg font-extrabold">
            Tu es <span className="gradient-text">#23</span> sur ENS
          </div>
          <div className="text-[11.5px] text-[var(--t2)]">Classement mis à jour chaque lundi matin</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 overflow-x-auto pb-2 mb-3 -mx-1 px-1" style={{ scrollbarWidth: "none" }}>
        {lbTabs.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-3 py-1.5 rounded-[20px] text-[11px] font-bold whitespace-nowrap transition-all shrink-0 ${
              activeTab === tab
                ? "bg-gradient-to-br from-[var(--ind)] to-[var(--cyn)] text-white"
                : "bg-[var(--bg3)] text-[var(--t2)] border border-[var(--b0)] hover:border-[var(--b1)]"
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2 mb-3.5">
        {[
          { value: "1 240", label: "Candidats", color: "var(--ind2)" },
          { value: "12.4", label: "Moy. générale", color: "var(--cyn)" },
          { value: "#23", label: "Mon rang", color: "var(--vio)" },
        ].map((stat, i) => (
          <div
            key={i}
            className="bg-[var(--surf)] border border-[var(--b0)] rounded-[12px] p-3 text-center"
          >
            <div
              className="font-[var(--font-syne)] text-xl font-extrabold"
              style={{ color: stat.color }}
            >
              {stat.value}
            </div>
            <div className="text-[9px] text-[var(--t3)] uppercase">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Table */}
      <div className="bg-[var(--surf)] border border-[var(--b0)] rounded-[14px] overflow-hidden">
        <div className="grid grid-cols-[auto_1fr_auto_auto] gap-3 p-3 border-b border-[var(--b0)] text-[10px] font-bold text-[var(--t3)] uppercase">
          <div>#</div>
          <div>Candidat</div>
          <div className="text-right">Note</div>
          <div className="text-right">Évol.</div>
        </div>

        {leaderboardData.map((row, i) => (
          <div key={i}>
            {row.pos === 23 && i > 0 && (
              <div className="h-px bg-[var(--b0)] mx-3" />
            )}
            <div
              className={`grid grid-cols-[auto_1fr_auto_auto] gap-3 p-3 items-center ${
                row.isMe ? "bg-gradient-to-r from-[var(--cyn-g)] to-transparent" : ""
              }`}
            >
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-extrabold ${
                  row.pos === 1
                    ? "bg-gradient-to-br from-[#FFD700] to-[#FFA500] text-black"
                    : row.pos === 2
                    ? "bg-gradient-to-br from-[#C0C0C0] to-[#A0A0A0] text-black"
                    : row.pos === 3
                    ? "bg-gradient-to-br from-[#CD7F32] to-[#A0522D] text-white"
                    : "bg-[var(--bg3)] text-[var(--t2)]"
                }`}
              >
                {row.pos}
              </div>

              <div className="flex items-center gap-2 min-w-0">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                    row.isMe
                      ? "bg-gradient-to-br from-[var(--ind)] to-[var(--cyn)] text-white"
                      : "bg-[var(--bg3)] text-[var(--t1)]"
                  }`}
                >
                  {row.initials}
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-[var(--t1)] truncate">
                    {row.name}
                    {row.isMe && <span className="text-[10px] text-[var(--cyn)] ml-1">(Toi)</span>}
                  </div>
                  <span
                    className={`text-[9px] font-bold py-0.5 px-1.5 rounded-[4px] ${
                      row.plan === "EXCELLENCE"
                        ? "bg-[var(--vio-g)] text-[var(--vio)]"
                        : row.plan === "ÉLITE"
                        ? "bg-[var(--cyn-g)] text-[var(--cyn)]"
                        : "bg-[var(--ind-g)] text-[var(--ind)]"
                    }`}
                  >
                    {row.plan}
                  </span>
                </div>
              </div>

              <div className="font-[var(--font-syne)] text-sm font-bold text-[var(--t1)] text-right">
                {row.score}
              </div>

              <div
                className={`text-[11px] font-bold text-right ${
                  row.up ? "text-[var(--grn)]" : "text-[var(--ros)]"
                }`}
              >
                {row.up ? "▲" : "▼"} {row.change}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="text-center text-[11px] text-[var(--t3)] mt-2.5">
        Classement basé sur les résultats du concours blanc du dimanche · Mis à jour chaque lundi à 6h00
      </div>
    </div>
  )
}
