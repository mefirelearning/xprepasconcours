"use client"

import { useState } from "react"

export function PlanningPane() {
  const [activeTab, setActiveTab] = useState<"day" | "week" | "program">("day")

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-5 max-w-[980px]">
      {/* Tabs */}
      <div className="flex gap-1 bg-[var(--bg3)] rounded-[10px] p-[3px] mb-4 border border-[var(--b0)]">
        {[
          { id: "day" as const, label: "Aujourd'hui" },
          { id: "week" as const, label: "Semaine" },
          { id: "program" as const, label: "Programme" },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 py-2 px-1.5 rounded-[8px] text-[11.5px] font-semibold text-center transition-all ${
              activeTab === tab.id
                ? "bg-[var(--surf)] text-[var(--ind)] font-bold shadow-[0_2px_8px_rgba(0,0,0,.1)]"
                : "text-[var(--t2)]"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === "day" && <DayPlan />}
      {activeTab === "week" && <WeekPlan />}
      {activeTab === "program" && <ProgramPlan />}
    </div>
  )
}

function DayPlan() {
  return (
    <div className="space-y-3">
      <DayPlanCard
        day="Lundi"
        date="6 mai"
        title="Révision intensive · Institutions"
        subtitle="Focus sur les points faibles identifiés"
        subjects={["Institutions", "Droit Civil", "Maths"]}
        notions={["Constitution du Cameroun", "Décrets fondamentaux", "Lois organiques"]}
        exercises={[
          { title: "QCM Institutions (30 questions)", difficulty: "Moyen" },
          { title: "Cas pratique Droit Civil", difficulty: "Facile" },
        ]}
        evaluation="Mini-évaluation de 15 min sur les institutions"
      />
      
      <DayPlanCard
        day="Mardi"
        date="7 mai"
        title="Entraînement · Épreuve type"
        subtitle="Simulation conditions réelles"
        subjects={["Culture Générale", "Rédaction"]}
        notions={["Actualité Cameroun 2025-2026", "Méthodologie dissertation"]}
        exercises={[
          { title: "Épreuve ENAM CG 2023", difficulty: "Difficile" },
          { title: "Plan détaillé dissertation", difficulty: "Moyen" },
        ]}
        evaluation="Correction IA complète avec feedback personnalisé"
        locked
      />
    </div>
  )
}

function DayPlanCard({
  day,
  date,
  title,
  subtitle,
  subjects,
  notions,
  exercises,
  evaluation,
  locked,
}: {
  day: string
  date: string
  title: string
  subtitle: string
  subjects: string[]
  notions: string[]
  exercises: { title: string; difficulty: string }[]
  evaluation: string
  locked?: boolean
}) {
  const subjectColors = ["m1", "m2", "m3", "m4"]
  const subjectBg: Record<string, string> = {
    m1: "var(--ind-g)",
    m2: "var(--cyn-g)",
    m3: "var(--vio-g)",
    m4: "var(--amb-g)",
  }
  const subjectText: Record<string, string> = {
    m1: "var(--ind)",
    m2: "var(--cyn)",
    m3: "var(--vio)",
    m4: "var(--amb)",
  }
  const diffColors: Record<string, { bg: string; color: string }> = {
    Facile: { bg: "rgba(15,170,117,.12)", color: "var(--grn)" },
    Moyen: { bg: "var(--amb-g)", color: "var(--amb)" },
    Difficile: { bg: "var(--ros-g)", color: "var(--ros)" },
  }

  return (
    <div className="bg-[var(--surf)] border border-[var(--b0)] rounded-[14px] p-4 relative overflow-hidden">
      <div className="absolute top-0 left-0 bottom-0 w-[3px] bg-gradient-to-b from-[var(--ind)] to-[var(--cyn)]" />
      
      <div className="flex items-center gap-2.5 mb-3">
        <span className="bg-gradient-to-br from-[var(--ind)] to-[var(--cyn)] text-white font-[var(--font-syne)] text-xs font-extrabold py-1.5 px-3 rounded-[20px]">
          {day}
        </span>
        <div>
          <div className="font-[var(--font-syne)] text-sm font-bold text-[var(--t1)]">{title}</div>
          <div className="text-[10.5px] text-[var(--t2)]">{subtitle}</div>
        </div>
      </div>

      <div className="flex flex-wrap gap-1.5 mb-3">
        {subjects.map((subject, i) => (
          <span
            key={i}
            className="py-1 px-2.5 rounded-[20px] text-[11px] font-semibold"
            style={{
              background: subjectBg[subjectColors[i % 4]],
              color: subjectText[subjectColors[i % 4]],
            }}
          >
            {subject}
          </span>
        ))}
      </div>

      <div className="text-[10px] font-bold text-[var(--t3)] tracking-[.08em] uppercase mb-[7px] mt-2.5">
        Notions à réviser
      </div>
      {notions.map((notion, i) => (
        <div key={i} className="flex items-center gap-2 p-2 bg-[var(--bg3)] rounded-[8px] mb-1.5 border border-[var(--b0)]">
          <span className="w-[7px] h-[7px] rounded-full bg-[var(--ind)] shrink-0" />
          <span className="text-xs text-[var(--t1)]">{notion}</span>
        </div>
      ))}

      <div className="text-[10px] font-bold text-[var(--t3)] tracking-[.08em] uppercase mb-[7px] mt-2.5">
        Exercices
      </div>
      {exercises.map((exercise, i) => (
        <div
          key={i}
          className="flex items-center gap-2 p-2 bg-[var(--bg3)] rounded-[8px] mb-1.5 border-l-2 border-l-[var(--cyn)] border-t border-r border-b border-[var(--b0)]"
        >
          <span
            className="text-[9px] font-extrabold py-0.5 px-1.5 rounded-[4px] shrink-0"
            style={{
              background: diffColors[exercise.difficulty].bg,
              color: diffColors[exercise.difficulty].color,
            }}
          >
            {exercise.difficulty === "Facile" ? "F" : exercise.difficulty === "Moyen" ? "M" : "D"}
          </span>
          <span className="text-xs text-[var(--t1)]">{exercise.title}</span>
        </div>
      ))}

      <div className="bg-gradient-to-br from-[rgba(68,82,217,.08)] to-[rgba(11,173,155,.06)] border border-[rgba(68,82,217,.2)] rounded-[10px] p-3 mt-2.5">
        <div className="text-[11.5px] font-bold text-[var(--ind)] mb-1 flex items-center gap-1.5">
          <span>📋</span>
          Évaluation du jour
        </div>
        <div className="text-[11px] text-[var(--t2)]">{evaluation}</div>
      </div>

      {locked && (
        <div className="bg-[rgba(15,23,42,.7)] backdrop-blur-[4px] rounded-[10px] p-4 text-center mt-2">
          <span className="text-2xl block mb-1.5">🔒</span>
          <div className="text-xs text-[var(--t2)] mb-2.5">Contenu ÉLITE requis</div>
          <button className="py-2 px-5 bg-gradient-to-br from-[var(--vio)] to-[var(--cyn)] rounded-[20px] text-xs font-bold text-white font-[var(--font-syne)]">
            Passer à ÉLITE
          </button>
        </div>
      )}

      {!locked && (
        <div className="flex gap-2 mt-3 flex-wrap">
          <button className="py-2 px-4 rounded-[20px] text-xs font-bold btn-primary text-white font-[var(--font-syne)]">
            Commencer
          </button>
          <button className="py-2 px-4 bg-[var(--bg3)] text-[var(--t2)] border border-[var(--b1)] rounded-[20px] text-xs font-bold font-[var(--font-syne)]">
            Voir détails
          </button>
        </div>
      )}
    </div>
  )
}

function WeekPlan() {
  return (
    <div className="bg-[var(--surf)] border border-[var(--b0)] rounded-[14px] p-4">
      <div className="font-[var(--font-syne)] text-base font-bold text-[var(--t1)] mb-3">
        Semaine du 6 au 12 mai
      </div>
      <div className="space-y-2">
        {["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"].map((day, i) => (
          <div
            key={day}
            className={`flex items-center gap-3 p-2.5 rounded-[10px] border ${
              i === 0
                ? "border-[var(--cyn)] bg-[var(--cyn-g)]"
                : "border-[var(--b0)] bg-[var(--bg3)]"
            }`}
          >
            <span className="font-[var(--font-syne)] text-xs font-bold w-8">{day}</span>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-semibold text-[var(--t1)]">
                {i === 0
                  ? "Institutions & Droit Civil"
                  : i === 6
                  ? "🏆 Concours Blanc ENAM"
                  : `Révision Matière ${i + 1}`}
              </div>
              <div className="text-[10px] text-[var(--t3)]">
                {i === 6 ? "13h00 — Durée 4h" : "2h de révision prévues"}
              </div>
            </div>
            {i === 0 && (
              <span className="text-[9px] font-bold py-0.5 px-2 rounded-[20px] bg-[var(--cyn)] text-black">
                Aujourd&apos;hui
              </span>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

function ProgramPlan() {
  return (
    <div className="bg-[var(--surf)] border border-[var(--b0)] rounded-[14px] p-4">
      <div className="font-[var(--font-syne)] text-base font-bold text-[var(--t1)] mb-1">
        Programme de révision personnalisé
      </div>
      <div className="text-xs text-[var(--t2)] mb-4">
        87 jours avant ENAM · Adapté à ton niveau et tes disponibilités
      </div>
      
      <div className="space-y-3">
        {[
          { week: "Semaine 1-4", title: "Fondamentaux", progress: 100, status: "Terminé" },
          { week: "Semaine 5-8", title: "Approfondissement", progress: 75, status: "En cours" },
          { week: "Semaine 9-12", title: "Entraînement intensif", progress: 0, status: "À venir" },
        ].map((phase, i) => (
          <div key={i} className="p-3 bg-[var(--bg3)] rounded-[12px] border border-[var(--b0)]">
            <div className="flex items-center justify-between mb-2">
              <div>
                <span className="text-[10px] text-[var(--t3)]">{phase.week}</span>
                <div className="text-sm font-bold text-[var(--t1)]">{phase.title}</div>
              </div>
              <span
                className={`text-[9px] font-bold py-0.5 px-2 rounded-[20px] ${
                  phase.progress === 100
                    ? "bg-[rgba(15,227,163,.12)] text-[var(--grn)]"
                    : phase.progress > 0
                    ? "bg-[var(--cyn-g)] text-[var(--cyn)]"
                    : "bg-[var(--bg3)] text-[var(--t3)] border border-[var(--b1)]"
                }`}
              >
                {phase.status}
              </span>
            </div>
            <div className="h-1.5 bg-[var(--b1)] rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-[var(--cyn)] to-[var(--vio)] rounded-full transition-all"
                style={{ width: `${phase.progress}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
