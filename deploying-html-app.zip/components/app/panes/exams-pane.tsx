"use client"

import { Clock } from "lucide-react"

export function ExamsPane() {
  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-5 max-w-[980px]">
      {/* Header */}
      <div className="bg-gradient-to-br from-[var(--surf)] to-[var(--surf2)] border border-[var(--b0)] rounded-[14px] p-4 mb-3.5 relative overflow-hidden">
        <div className="absolute top-[-40%] right-[-10%] w-[200px] h-[200px] bg-[radial-gradient(circle,rgba(144,97,249,.1),transparent_60%)] pointer-events-none" />
        <div className="flex items-center gap-3 relative">
          <div className="w-12 h-12 shrink-0 bg-gradient-to-br from-[var(--vio)] to-[var(--cyn)] rounded-[12px] flex items-center justify-center text-2xl shadow-[0_4px_16px_rgba(144,97,249,.4)]">
            📝
          </div>
          <div className="flex-1 min-w-0">
            <div className="font-[var(--font-syne)] text-lg font-extrabold text-[var(--t1)]">
              Examens Blancs
            </div>
            <div className="text-xs text-[var(--t2)]">
              Chaque dimanche · Conditions réelles · Classement national
            </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2 mb-3.5">
        {[
          { value: "12", label: "Blancs passés", color: "var(--ind2)" },
          { value: "14.2", label: "Moyenne", color: "var(--cyn)" },
          { value: "#23", label: "Meilleur rang", color: "var(--vio)" },
        ].map((stat, i) => (
          <div
            key={i}
            className="bg-[var(--surf)] border border-[var(--b0)] rounded-[12px] p-3 text-center"
          >
            <div
              className="font-[var(--font-syne)] text-xl font-extrabold"
              style={{ color: stat.color }}
            >
              {stat.value}
            </div>
            <div className="text-[9px] text-[var(--t3)] uppercase">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Section Title */}
      <div className="flex items-center justify-between mb-2.5 mt-4">
        <span className="text-[10px] font-bold text-[var(--t3)] tracking-[.1em] uppercase">
          Prochains examens
        </span>
      </div>

      {/* Exam Cards */}
      <div className="space-y-3">
        <ExamCard
          concours="ENAM"
          status="upcoming"
          date="Dimanche 18 mai"
          time="13h00"
          duration="4h"
        />
        <ExamCard
          concours="FMSB"
          status="live"
          date="Dimanche 11 mai"
          time="14h00"
          duration="3h"
          timeRemaining="1h 23min"
        />
        <ExamCard
          concours="ENS"
          status="corrections"
          date="Dimanche 4 mai"
          score={14.5}
          rank={23}
          total={180}
          change="+2 points"
        />
        <ExamCard
          concours="ESSEC"
          status="done"
          date="Dimanche 27 avril"
          score={11.0}
          rank={47}
          total={95}
          avgScore={10.4}
        />
      </div>
    </div>
  )
}

function ExamCard({
  concours,
  status,
  date,
  time,
  duration,
  timeRemaining,
  score,
  rank,
  total,
  change,
  avgScore,
}: {
  concours: string
  status: "upcoming" | "live" | "corrections" | "done"
  date: string
  time?: string
  duration?: string
  timeRemaining?: string
  score?: number
  rank?: number
  total?: number
  change?: string
  avgScore?: number
}) {
  const statusConfig = {
    upcoming: { label: "À venir", color: "var(--ind)", bg: "var(--ind-g)" },
    live: { label: "🔴 En cours", color: "var(--ros)", bg: "var(--ros-g)" },
    corrections: { label: "Corrections dispo", color: "var(--cyn)", bg: "var(--cyn-g)" },
    done: { label: "Terminé", color: "var(--t3)", bg: "var(--bg3)" },
  }

  const colorMap: Record<string, string> = {
    ENAM: "var(--ind)",
    FMSB: "var(--cyn)",
    ENS: "var(--grn)",
    ESSEC: "var(--vio)",
    ENSP: "var(--amb)",
    IUT: "var(--ros)",
  }

  const cfg = statusConfig[status]

  return (
    <div className="bg-[var(--surf)] border border-[var(--b0)] rounded-[14px] p-4 relative overflow-hidden">
      <div
        className="absolute top-0 left-0 right-0 h-[3px]"
        style={{
          background: `linear-gradient(90deg, ${colorMap[concours] || "var(--ind)"}, ${
            status === "live" ? "var(--ros)" : "var(--cyn)"
          })`,
        }}
      />

      <div className="flex items-center justify-between mb-2">
        <span
          className="font-[var(--font-syne)] text-sm font-extrabold"
          style={{ color: colorMap[concours] }}
        >
          {concours}
        </span>
        <span
          className="text-[10px] font-bold py-0.5 px-2 rounded-[20px]"
          style={{ background: cfg.bg, color: cfg.color }}
        >
          {cfg.label}
        </span>
      </div>

      <div className="flex items-center gap-1.5 text-[11px] text-[var(--t2)] mb-2">
        <Clock size={12} className="text-[var(--t3)]" />
        {date}
        {time && (
          <>
            {" · "}
            <b>{time}</b>
          </>
        )}
        {duration && <> · {duration}</>}
        {timeRemaining && (
          <>
            {" · Fin : "}
            <b style={{ color: "var(--ros)" }}>Temps restant : {timeRemaining}</b>
          </>
        )}
      </div>

      {(status === "corrections" || status === "done") && score !== undefined && (
        <div className="flex items-center gap-3 mt-2 mb-2">
          <div className="font-[var(--font-syne)] text-2xl font-extrabold" style={{ color: colorMap[concours] }}>
            {score.toFixed(1)}
            <span className="text-sm text-[var(--t2)]">/20</span>
          </div>
          <div className="flex-1 min-w-0">
            {change && <div className="text-[11px] text-[var(--grn)]">{change} vs semaine dernière</div>}
            {avgScore && <div className="text-[11px] text-[var(--t3)]">Score moyen groupe : {avgScore}</div>}
            <div className="text-[11px] text-[var(--t2)]">
              🏅 Classé #{rank} sur {total}
            </div>
          </div>
        </div>
      )}

      <div className="flex gap-2 mt-3">
        {status === "upcoming" && (
          <>
            <button className="py-2 px-4 rounded-[20px] text-xs font-bold btn-primary text-white">
              S&apos;inscrire
            </button>
            <button className="py-2 px-4 bg-[var(--bg3)] text-[var(--t2)] border border-[var(--b1)] rounded-[20px] text-xs font-bold">
              Voir programme
            </button>
          </>
        )}
        {status === "live" && (
          <button className="py-2 px-4 rounded-[20px] text-xs font-bold bg-gradient-to-br from-[var(--ros)] to-[var(--vio)] text-white">
            Envoyer mes réponses
          </button>
        )}
        {(status === "corrections" || status === "done") && (
          <button className="py-2 px-4 rounded-[20px] text-xs font-bold bg-gradient-to-br from-[var(--cyn)] to-[var(--grn)] text-black">
            Voir ma correction
          </button>
        )}
      </div>
    </div>
  )
}
