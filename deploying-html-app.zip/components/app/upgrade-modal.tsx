"use client"

import { X, Check, Sparkles, Zap, Crown } from "lucide-react"

interface UpgradeModalProps {
  isOpen: boolean
  onClose: () => void
}

export function UpgradeModal({ isOpen, onClose }: UpgradeModalProps) {
  if (!isOpen) return null

  const plans = [
    {
      name: "Gratuit",
      price: "0",
      period: "FCFA/mois",
      features: [
        "Accès limité aux QCM",
        "5 questions IA/jour",
        "Statistiques basiques",
      ],
      current: true,
    },
    {
      name: "Pro",
      price: "4,900",
      period: "FCFA/mois",
      features: [
        "Accès illimité aux QCM",
        "Questions IA illimitées",
        "Examens blancs complets",
        "Planning personnalisé",
        "Statistiques avancées",
      ],
      popular: true,
    },
    {
      name: "Premium",
      price: "9,900",
      period: "FCFA/mois",
      features: [
        "Tout le plan Pro",
        "Coaching personnalisé",
        "Accès prioritaire",
        "Sessions en direct",
        "Support dédié",
      ],
    },
  ]

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-card border border-border rounded-2xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center">
                <Crown className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-foreground">Passer à Premium</h2>
                <p className="text-sm text-muted-foreground">Débloquez tout le potentiel de votre préparation</p>
              </div>
            </div>
            <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-6">
          <div className="grid md:grid-cols-3 gap-4">
            {plans.map((plan) => (
              <div
                key={plan.name}
                className={`relative p-6 rounded-xl border ${
                  plan.popular
                    ? "border-primary bg-primary/5"
                    : "border-border bg-card"
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-xs font-medium px-3 py-1 rounded-full flex items-center gap-1">
                    <Sparkles className="w-3 h-3" />
                    Populaire
                  </div>
                )}

                <div className="text-center mb-6">
                  <h3 className="text-lg font-semibold text-foreground mb-2">{plan.name}</h3>
                  <div className="flex items-baseline justify-center gap-1">
                    <span className="text-3xl font-bold text-foreground">{plan.price}</span>
                    <span className="text-sm text-muted-foreground">{plan.period}</span>
                  </div>
                </div>

                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2 text-sm text-foreground">
                      <Check className="w-4 h-4 text-success flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <button
                  className={`w-full py-2.5 rounded-lg font-medium transition-colors ${
                    plan.current
                      ? "bg-muted text-muted-foreground cursor-default"
                      : plan.popular
                      ? "bg-primary text-primary-foreground hover:bg-primary/90"
                      : "bg-muted text-foreground hover:bg-muted/80"
                  }`}
                  disabled={plan.current}
                >
                  {plan.current ? "Plan actuel" : "Choisir ce plan"}
                </button>
              </div>
            ))}
          </div>

          <div className="mt-6 p-4 bg-muted/50 rounded-xl">
            <div className="flex items-center gap-3">
              <Zap className="w-5 h-5 text-warning" />
              <div>
                <p className="text-sm font-medium text-foreground">Garantie satisfait ou remboursé</p>
                <p className="text-xs text-muted-foreground">
                  Essayez Premium pendant 7 jours. Si vous n&apos;êtes pas satisfait, nous vous remboursons.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
