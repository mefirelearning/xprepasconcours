"use client"

import { LogoMark } from "@/components/ui/logo"
import type { AppPane } from "@/components/views/main-app"
import { 
  Home, MessageCircle, Users, BookOpen, Calendar, Folder, Zap, 
  FileText, Trophy, BarChart3, CreditCard, LayoutGrid, Plus, 
  Settings, Moon, Sun, Star, X
} from "lucide-react"

interface SidebarProps {
  currentPane: AppPane
  setCurrentPane: (pane: AppPane) => void
  isOpen: boolean
  onClose: () => void
  onOpenProfile: () => void
  onOpenModal: () => void
  isDark: boolean
  toggleTheme: () => void
}

const mainNavItems: { id: AppPane; label: string; icon: React.ComponentType<{ size?: number; className?: string }> ; badge?: string }[] = [
  { id: "home", label: "Accueil", icon: Home },
  { id: "chat", label: "Professeur IA", icon: MessageCircle },
  { id: "coach", label: "Coach Méthodes", icon: Users },
  { id: "concours", label: "Épreuves", icon: BookOpen, badge: "+80" },
  { id: "planning", label: "Planning", icon: Calendar },
  { id: "projects", label: "Projets", icon: Folder },
  { id: "contest", label: "Mode Concours", icon: Zap },
  { id: "exams", label: "Examens Blancs", icon: FileText, badge: "Dim" },
  { id: "leaderboard", label: "Classement", icon: Trophy },
  { id: "stats", label: "Statistiques", icon: BarChart3 },
  { id: "subscription", label: "Abonnements", icon: CreditCard },
  { id: "admin", label: "Admin Dashboard", icon: LayoutGrid },
]

export function Sidebar({ currentPane, setCurrentPane, isOpen, onClose, onOpenProfile, onOpenModal, isDark, toggleTheme }: SidebarProps) {
  return (
    <aside 
      className={`w-[258px] min-w-[258px] bg-[var(--bg2)] border-r border-[var(--b0)] flex flex-col h-full overflow-hidden shrink-0 relative transition-transform duration-300 ease-[cubic-bezier(.4,0,.2,1)] 
        md:translate-x-0 
        ${isOpen ? "translate-x-0 absolute top-0 left-0 bottom-0 z-[200] shadow-[0_20px_60px_rgba(0,0,0,.5)]" : "-translate-x-full absolute md:relative"}
      `}
    >
      {/* Decorative line */}
      <div className="absolute top-0 right-0 w-px h-full bg-gradient-to-b from-transparent via-[rgba(144,97,249,.2)] to-transparent pointer-events-none" />
      
      {/* Top */}
      <div className="flex items-center justify-between px-3.5 pt-4 pb-3.5 border-b border-[var(--b0)] shrink-0">
        <div className="flex items-center gap-2">
          <LogoMark size={32} />
          <div>
            <div className="font-[var(--font-syne)] text-[13px] font-extrabold gradient-text">Prépas Concours AI</div>
            <div className="text-[9px] text-[var(--t3)] uppercase tracking-[.06em]">Cameroun · 2026</div>
          </div>
        </div>
        <div className="flex gap-1.5 items-center">
          <button 
            onClick={toggleTheme}
            className="w-7 h-7 bg-[var(--bg3)] border border-[var(--b1)] rounded-[7px] flex items-center justify-center hover:border-[var(--cyn)] transition-all shrink-0"
            title={isDark ? "Activer le mode clair" : "Activer le mode sombre"}
          >
            {isDark ? <Sun size={14} className="text-[var(--amb)]" /> : <Moon size={14} className="text-[var(--ind)]" />}
          </button>
          <button 
            onClick={onClose}
            className="w-[26px] h-[26px] bg-[var(--bg3)] border border-[var(--b1)] rounded-[7px] items-center justify-center text-[var(--t2)] shrink-0 hidden md:hidden flex"
          >
            <X size={14} />
          </button>
        </div>
      </div>

      {/* Upgrade Card */}
      <div 
        onClick={onOpenModal}
        className="mx-3 mt-3 mb-2 p-3 bg-gradient-to-br from-[var(--vio-g)] to-[var(--cyn-g)] border border-[rgba(144,97,249,.25)] rounded-[12px] cursor-pointer transition-all relative overflow-hidden hover:border-[var(--vio)] shine-effect shrink-0"
      >
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 bg-gradient-to-br from-[var(--vio)] to-[var(--cyn)] rounded-[8px] flex items-center justify-center shadow-[0_4px_12px_rgba(144,97,249,.35)] shrink-0">
            <Star size={14} className="text-white" />
          </div>
          <div>
            <div className="text-xs font-bold text-[var(--t1)]">Mise à niveau</div>
            <div className="text-[10px] text-[var(--t3)]">Atteins le niveau MAJOR</div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-2.5 py-2 overflow-y-auto" style={{ scrollbarWidth: "none" }}>
        <div className="text-[9.5px] font-semibold text-[var(--t3)] tracking-[.1em] uppercase px-2 pt-3 pb-1.5">
          Principal
        </div>
        
        {mainNavItems.map((item) => {
          const Icon = item.icon
          const isActive = currentPane === item.id
          return (
            <div 
              key={item.id}
              onClick={() => setCurrentPane(item.id)}
              className={`flex items-center gap-2.5 py-2 px-2.5 rounded-[10px] cursor-pointer text-[12.5px] font-medium mb-0.5 transition-all relative ${
                isActive 
                  ? "bg-gradient-to-r from-[rgba(24,224,203,.1)] to-transparent text-[var(--cyn)] font-semibold" 
                  : "text-[var(--t2)] hover:bg-[var(--bg3)] hover:text-[var(--t1)]"
              }`}
            >
              {isActive && (
                <div className="absolute left-0 top-[7px] bottom-[7px] w-[3px] bg-gradient-to-b from-[var(--cyn)] to-[var(--vio)] rounded-[2px]" />
              )}
              <div className="w-5 h-5 shrink-0 flex items-center justify-center">
                <Icon size={16} />
              </div>
              {item.label}
              {item.badge && (
                <span className="ml-auto text-[9px] font-bold bg-[rgba(24,224,203,.12)] text-[var(--cyn)] py-0.5 px-[7px] rounded-[20px]">
                  {item.badge}
                </span>
              )}
            </div>
          )
        })}

        <div className="text-[9.5px] font-semibold text-[var(--t3)] tracking-[.1em] uppercase px-2 pt-3 pb-1.5 mt-2">
          Mes Concours
        </div>
        
        <div className="flex items-center gap-2.5 py-2 px-2.5 rounded-[10px] cursor-pointer text-[12.5px] font-medium text-[var(--t2)] hover:bg-[var(--bg3)] hover:text-[var(--t1)] transition-all">
          <div className="w-5 h-5 shrink-0 flex items-center justify-center">
            <BookOpen size={16} />
          </div>
          ENAM
        </div>
        <div className="flex items-center gap-2.5 py-2 px-2.5 rounded-[10px] cursor-pointer text-[12.5px] font-medium text-[var(--t2)] hover:bg-[var(--bg3)] hover:text-[var(--t1)] transition-all">
          <div className="w-5 h-5 shrink-0 flex items-center justify-center">
            <BookOpen size={16} />
          </div>
          FMSB
        </div>
        <div className="flex items-center gap-2.5 py-2 px-2.5 rounded-[10px] cursor-pointer text-[11.5px] text-[var(--cyn)] hover:bg-[var(--bg3)] transition-all">
          <div className="w-5 h-5 shrink-0 flex items-center justify-center">
            <Plus size={16} />
          </div>
          Ajouter
        </div>
      </nav>

      {/* Footer */}
      <div className="p-2.5 border-t border-[var(--b0)] shrink-0">
        <div 
          onClick={onOpenProfile}
          className="flex items-center gap-2 py-2 px-2.5 rounded-[10px] cursor-pointer hover:bg-[var(--bg3)] transition-all"
        >
          <div className="w-8 h-8 shrink-0 bg-gradient-to-br from-[var(--ind)] to-[var(--vio)] rounded-full flex items-center justify-center text-[13px] shadow-[0_0_10px_rgba(144,97,249,.3)]">
            🎓
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-[12.5px] font-semibold text-[var(--t1)]">Mefire Fifen</div>
            <div className="text-[9px] text-[var(--cyn)] font-semibold flex items-center gap-[3px] mt-0.5">
              <span className="w-[5px] h-[5px] rounded-full bg-[var(--cyn)] shadow-[0_0_5px_var(--cyn)] online-dot" />
              MASTERY · Lvl 4
            </div>
          </div>
          <button className="w-[26px] h-[26px] bg-[var(--bg3)] border border-[var(--b1)] rounded-[7px] flex items-center justify-center hover:border-[var(--cyn)] transition-all">
            <Settings size={14} className="text-[var(--t3)] hover:text-[var(--cyn)]" />
          </button>
        </div>
      </div>
    </aside>
  )
}
