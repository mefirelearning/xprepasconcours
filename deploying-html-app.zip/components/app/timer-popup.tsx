"use client"

import { X, Play, Pause, RotateCcw } from "lucide-react"
import { useState, useEffect } from "react"

interface TimerPopupProps {
  isOpen: boolean
  onClose: () => void
}

export function TimerPopup({ isOpen, onClose }: TimerPopupProps) {
  const [minutes, setMinutes] = useState(25)
  const [seconds, setSeconds] = useState(0)
  const [isRunning, setIsRunning] = useState(false)
  const [selectedPreset, setSelectedPreset] = useState(25)

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null
    
    if (isRunning && (minutes > 0 || seconds > 0)) {
      interval = setInterval(() => {
        if (seconds === 0) {
          if (minutes > 0) {
            setMinutes(minutes - 1)
            setSeconds(59)
          }
        } else {
          setSeconds(seconds - 1)
        }
      }, 1000)
    } else if (minutes === 0 && seconds === 0 && isRunning) {
      setIsRunning(false)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isRunning, minutes, seconds])

  const handlePresetChange = (preset: number) => {
    setSelectedPreset(preset)
    setMinutes(preset)
    setSeconds(0)
    setIsRunning(false)
  }

  const handleReset = () => {
    setMinutes(selectedPreset)
    setSeconds(0)
    setIsRunning(false)
  }

  if (!isOpen) return null

  return (
    <div className="fixed bottom-20 right-4 z-50 bg-card border border-border rounded-2xl shadow-xl p-4 w-72">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-foreground">Minuteur Pomodoro</h3>
        <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="text-center mb-4">
        <div className="text-5xl font-bold text-primary tabular-nums">
          {String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")}
        </div>
      </div>

      <div className="flex gap-2 mb-4">
        {[15, 25, 45, 60].map((preset) => (
          <button
            key={preset}
            onClick={() => handlePresetChange(preset)}
            className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${
              selectedPreset === preset
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            {preset}m
          </button>
        ))}
      </div>

      <div className="flex gap-2">
        <button
          onClick={() => setIsRunning(!isRunning)}
          className="flex-1 flex items-center justify-center gap-2 py-2 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors"
        >
          {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          {isRunning ? "Pause" : "Démarrer"}
        </button>
        <button
          onClick={handleReset}
          className="p-2 bg-muted text-muted-foreground rounded-lg hover:bg-muted/80 transition-colors"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>
    </div>
  )
}
