"use client"

import type { AppPane } from "@/components/views/main-app"
import { Menu, Home, MessageCircle, Users, BookOpen, Calendar, Folder, Zap, FileText, Trophy, BarChart3, CreditCard, LayoutGrid, Star, Clock } from "lucide-react"

interface TopBarProps {
  title: string
  currentPane: AppPane
  onMenuClick: () => void
  onTimerClick: () => void
  onUpgradeClick: () => void
  timerSeconds: number
  timerRunning: boolean
  isMobile?: boolean
}

const paneIcons: Record<AppPane, React.ComponentType<{ size?: number; className?: string }>> = {
  home: Home,
  chat: MessageCircle,
  coach: Users,
  concours: BookOpen,
  planning: Calendar,
  projects: Folder,
  contest: Zap,
  exams: FileText,
  leaderboard: Trophy,
  stats: BarChart3,
  subscription: CreditCard,
  admin: LayoutGrid,
}

function formatTime(seconds: number) {
  const mins = Math.floor(seconds / 60)
  const secs = seconds % 60
  return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`
}

export function TopBar({ title, currentPane, onMenuClick, onTimerClick, onUpgradeClick, timerSeconds, timerRunning, isMobile }: TopBarProps) {
  const Icon = paneIcons[currentPane]
  
  if (isMobile) {
    return (
      <div className="flex items-center justify-between px-4 py-3 border-b border-[var(--b1)] bg-white/[.92] dark:bg-[rgba(4,8,18,.7)] backdrop-blur-[20px] shrink-0 gap-2.5 md:hidden">
        <button 
          onClick={onMenuClick}
          className="w-[34px] h-[34px] bg-[var(--surf)] border border-[var(--b1)] rounded-[9px] flex items-center justify-center hover:border-[var(--b2)] transition-all shrink-0"
        >
          <Menu size={16} className="text-[var(--t1)]" />
        </button>
        
        <div className="font-[var(--font-syne)] text-[15px] font-bold text-[var(--t1)] flex-1 min-w-0 flex items-center gap-[7px]">
          <div className="w-5 h-5 shrink-0 flex items-center justify-center">
            <Icon size={17} className="text-[var(--cyn)]" />
          </div>
          <span className="text-[13px] whitespace-nowrap overflow-hidden text-ellipsis">{title}</span>
        </div>
        
        <div className="flex gap-[7px] items-center">
          <button 
            onClick={onTimerClick}
            className={`flex items-center gap-[5px] bg-[rgba(245,166,35,.08)] border border-[rgba(245,166,35,.25)] rounded-[20px] py-[5px] px-[11px] text-[11px] font-bold text-[var(--amb)] font-mono whitespace-nowrap ${
              timerRunning ? "timer-running" : ""
            }`}
          >
            <Clock size={12} />
            {formatTime(timerSeconds)}
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="hidden md:flex items-center justify-between px-5 py-3 border-b border-[var(--b1)] bg-white/[.92] dark:bg-[rgba(4,8,18,.6)] backdrop-blur-[20px] shrink-0 gap-2.5">
      <div className="flex items-center gap-2.5 min-w-0">
        <div className="text-base font-bold text-[var(--t1)] flex items-center gap-2 whitespace-nowrap">
          <div className="w-[22px] h-[22px] shrink-0 flex items-center justify-center">
            <Icon size={18} className="text-[var(--cyn)]" />
          </div>
          {title}
        </div>
      </div>
      
      <div className="flex gap-2 items-center shrink-0">
        <button 
          onClick={onTimerClick}
          className={`flex items-center gap-1.5 bg-[rgba(245,166,35,.08)] border border-[rgba(245,166,35,.25)] rounded-[20px] py-[5px] px-3 text-[11px] font-bold text-[var(--amb)] font-mono whitespace-nowrap hover:bg-[rgba(245,166,35,.14)] transition-all ${
            timerRunning ? "timer-running" : ""
          }`}
        >
          <Clock size={12} />
          {formatTime(timerSeconds)}
        </button>
        
        <button 
          onClick={onUpgradeClick}
          className="flex items-center gap-[5px] py-[7px] px-3.5 bg-gradient-to-br from-[var(--vio)] to-[var(--cyn)] rounded-[20px] text-[11.5px] font-bold text-white font-[var(--font-syne)] shadow-[0_4px_12px_rgba(144,97,249,.4)] hover:scale-[1.04] transition-all whitespace-nowrap"
        >
          <Star size={12} />
          Mise à niveau
        </button>
      </div>
    </div>
  )
}
