"use client"

import { X, Moon, Sun, Bell, Lock, LogOut, ChevronRight, User, Pencil } from "lucide-react"

interface ProfilePanelProps {
  isOpen: boolean
  onClose: () => void
  isDark: boolean
  toggleTheme: () => void
}

export function ProfilePanel({ isOpen, onClose, isDark, toggleTheme }: ProfilePanelProps) {
  if (!isOpen) return null

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black/60 z-[299] backdrop-blur-[4px]"
        onClick={onClose}
      />

      {/* Panel */}
      <div className="fixed top-0 right-0 bottom-0 w-full max-w-[340px] bg-[var(--bg2)] border-l border-[var(--b0)] z-[300] flex flex-col overflow-hidden animate-[slideIn_0.3s_ease]">
        <style jsx>{`
          @keyframes slideIn {
            from { transform: translateX(100%); }
            to { transform: translateX(0); }
          }
        `}</style>

        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3.5 border-b border-[var(--b0)] shrink-0">
          <div className="font-[var(--font-syne)] text-base font-bold text-[var(--t1)]">Mon Profil</div>
          <button 
            onClick={onClose}
            className="w-8 h-8 bg-[var(--bg3)] border border-[var(--b1)] rounded-[8px] flex items-center justify-center text-[var(--t2)] hover:border-[var(--b2)] hover:text-[var(--t1)] transition-all"
          >
            <X size={16} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 bg-[var(--bg3)]">
          {/* User Card */}
          <div className="bg-[var(--surf)] border border-[var(--b0)] rounded-[14px] p-4 text-center mb-4">
            <div className="w-16 h-16 mx-auto bg-gradient-to-br from-[var(--ind)] to-[var(--vio)] rounded-full flex items-center justify-center text-2xl shadow-[0_8px_24px_rgba(144,97,249,.4)] mb-3">
              🎓
            </div>
            <div className="font-[var(--font-syne)] text-lg font-extrabold text-[var(--t1)]">
              Mefire Fifen
            </div>
            <div className="text-xs text-[var(--t3)] mb-2">mefire@email.cm</div>
            <div className="inline-flex items-center gap-[5px] bg-[var(--cyn-g)] border border-[rgba(24,224,203,.3)] rounded-[20px] py-1 px-3 text-[11px] font-bold text-[var(--cyn)]">
              <span className="w-[5px] h-[5px] rounded-full bg-[var(--cyn)] online-dot" />
              MASTERY
            </div>

            <button className="flex items-center justify-center gap-[5px] w-full py-2 mt-3 bg-[var(--bg3)] border border-[var(--b1)] rounded-[10px] text-[12.5px] font-semibold text-[var(--t1)] hover:border-[var(--b2)] transition-all">
              <Pencil size={13} />
              Modifier mon profil
            </button>
          </div>

          {/* Section: Preferences */}
          <div className="text-[10px] font-bold text-[var(--t3)] tracking-[.1em] uppercase mb-2 mt-4">
            Préférences
          </div>

          <div className="bg-[var(--bg3)] border border-[var(--b0)] rounded-[11px] overflow-hidden">
            <ToggleItem 
              icon={isDark ? <Sun size={15} /> : <Moon size={15} />}
              label="Mode sombre"
              sublabel={isDark ? "Activé" : "Désactivé"}
              isOn={isDark}
              onToggle={toggleTheme}
            />
            <ToggleItem 
              icon={<Bell size={15} />}
              label="Notifications"
              sublabel="Push & Email"
              isOn={true}
            />
          </div>

          {/* Section: Account */}
          <div className="text-[10px] font-bold text-[var(--t3)] tracking-[.1em] uppercase mb-2 mt-4">
            Compte
          </div>

          <div className="space-y-[7px]">
            <MenuItem icon={<User size={16} />} label="Informations personnelles" />
            <MenuItem icon={<Lock size={16} />} label="Sécurité & mot de passe" />
          </div>

          {/* Danger Zone */}
          <button className="w-full mt-4 p-3 bg-[rgba(240,97,138,.06)] border border-[rgba(240,97,138,.2)] rounded-[11px] text-left hover:border-[rgba(240,97,138,.4)] transition-all">
            <div className="flex items-center gap-2.5">
              <LogOut size={16} className="text-[var(--ros)]" />
              <div>
                <div className="text-[13px] font-semibold text-[var(--ros)]">Se déconnecter</div>
                <div className="text-[10.5px] text-[var(--t3)]">Revenir à l&apos;écran de connexion</div>
              </div>
            </div>
          </button>

          {/* Version */}
          <div className="text-center text-[10px] text-[var(--t3)] py-3 mt-2">
            Prépas Concours AI · v2.4.0
          </div>
        </div>
      </div>
    </>
  )
}

function ToggleItem({ 
  icon, 
  label, 
  sublabel, 
  isOn, 
  onToggle 
}: { 
  icon: React.ReactNode
  label: string
  sublabel?: string
  isOn: boolean
  onToggle?: () => void
}) {
  return (
    <div className="flex items-center justify-between p-3 border-b border-[var(--b0)] last:border-b-0">
      <div className="flex items-center gap-2.5">
        <div className="w-[26px] h-[26px] flex items-center justify-center text-[var(--t2)]">
          {icon}
        </div>
        <div>
          <div className="text-[13px] font-semibold text-[var(--t1)]">{label}</div>
          {sublabel && <div className="text-[10.5px] text-[var(--t3)]">{sublabel}</div>}
        </div>
      </div>
      <button 
        onClick={onToggle}
        className={`w-10 h-[22px] rounded-[11px] relative transition-all shrink-0 ${
          isOn ? "bg-gradient-to-r from-[var(--ind)] to-[var(--cyn)]" : "bg-[var(--b1)]"
        }`}
      >
        <div 
          className={`absolute top-[3px] w-4 h-4 rounded-full bg-white shadow-[0_2px_4px_rgba(0,0,0,.3)] transition-transform ${
            isOn ? "translate-x-[21px]" : "translate-x-[3px]"
          }`}
        />
      </button>
    </div>
  )
}

function MenuItem({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <div className="flex items-center gap-2.5 p-3 bg-[var(--bg3)] border border-[var(--b0)] rounded-[11px] cursor-pointer hover:border-[var(--b1)] transition-all">
      <div className="w-[26px] h-[26px] flex items-center justify-center text-[var(--cyn)]">
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-[13px] font-semibold text-[var(--t1)]">{label}</div>
      </div>
      <ChevronRight size={14} className="text-[var(--t3)]" />
    </div>
  )
}
